# main.py

import csv
import json
import warnings

from dataclasses import asdict, replace
from pathlib import Path
from typing import Callable

import numpy as np

from config import (
    CONFIG,
    OUTPUT_DIR,
    RUN_PARAMETER_SWEEPS,
    PARAMETER_SWEEP,
    GameConfig,
)
from game import SecurityGame, State, DefenseAction
from algorithms import (
    train_multi_agent_q_learning,
    highest_value_policy,
    uniform_policy,
    q_learning_policy,
    attacker_q_policy,
    solve_best_response_value_iteration,
    best_response_dp_policy,
)


# Matplotlib is optional; simulation and CSV output still work without it.
try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None


PolicyFunction = Callable[[State], DefenseAction]
AttackerPolicyFunction = Callable[[State, DefenseAction], int]


# =========================================================
# 1. FILE OUTPUT UTILITIES
# =========================================================


def save_csv(path: Path, rows: list[dict]) -> None:
    """Save a list of dictionaries as a CSV file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return

    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def save_config(config: GameConfig, output_dir: Path) -> None:
    """Save the exact configuration used in an experiment."""
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "config.json").open("w", encoding="utf-8") as file:
        json.dump(asdict(config), file, indent=2)


# =========================================================
# 2. EVALUATE A DEFENDER-ATTACKER POLICY PAIR
# =========================================================


def evaluate_policy(
    config: GameConfig,
    defender_policy: PolicyFunction,
    attacker_policy: AttackerPolicyFunction,
    seed: int,
) -> dict:
    """Evaluate one policy pair over independent episodes.

    The attacker receives the current infection state and the actual
    defense allocation chosen on that turn, exactly as during training.
    """
    env = SecurityGame(config, seed=seed)

    defender_returns = []
    attacker_returns = []
    defender_rewards = []
    attacker_rewards = []
    episode_losses = []
    episode_defense_costs = []
    episode_attack_costs = []

    attacks_per_target = np.zeros(config.K, dtype=np.int64)
    successful_attacks = 0
    eligible_attack_attempts = 0
    total_new_infections = 0
    total_recoveries = 0

    for _ in range(config.eval_episodes):
        state = env.reset()

        defender_return = 0.0
        attacker_return = 0.0
        defender_reward_sum = 0.0
        attacker_reward_sum = 0.0
        cumulative_loss = 0.0
        defense_cost_sum = 0.0
        attack_cost_sum = 0.0

        for step in range(config.eval_horizon):
            defense = tuple(defender_policy(state))
            if not env.is_valid_action(defense):
                raise ValueError(
                    f"Defender returned invalid allocation: {defense}"
                )

            attack_target = int(attacker_policy(state, defense))
            if not env.is_valid_attack(attack_target):
                raise ValueError(
                    f"Attacker returned invalid target: {attack_target}"
                )

            next_state, defender_reward, info = env.step(
                defense,
                attack_target,
            )
            attacker_reward = float(info["attacker_reward"])

            discount = config.gamma ** step
            defender_return += discount * defender_reward
            attacker_return += discount * attacker_reward
            defender_reward_sum += defender_reward
            attacker_reward_sum += attacker_reward
            cumulative_loss += info["infected_value"]
            defense_cost_sum += info["defense_cost"]
            attack_cost_sum += info["attack_cost"]

            attacks_per_target[attack_target] += 1
            if info["state_before"][attack_target] == 0:
                eligible_attack_attempts += 1
                if info["new_infection"]:
                    successful_attacks += 1

            total_new_infections += int(info["new_infection"])
            total_recoveries += len(info["recovered_targets"])
            state = next_state

        defender_returns.append(defender_return)
        attacker_returns.append(attacker_return)
        defender_rewards.append(defender_reward_sum)
        attacker_rewards.append(attacker_reward_sum)
        episode_losses.append(cumulative_loss)
        episode_defense_costs.append(defense_cost_sum)
        episode_attack_costs.append(attack_cost_sum)

    total_attack_attempts = config.eval_episodes * config.eval_horizon
    attack_success_rate = (
        successful_attacks / eligible_attack_attempts
        if eligible_attack_attempts > 0
        else float("nan")
    )

    metrics = {
        "mean_discounted_return": float(np.mean(defender_returns)),
        "std_discounted_return": float(np.std(defender_returns)),
        "mean_discounted_attacker_return": float(np.mean(attacker_returns)),
        "std_discounted_attacker_return": float(np.std(attacker_returns)),
        "mean_episode_reward": float(np.mean(defender_rewards)),
        "mean_attacker_episode_reward": float(np.mean(attacker_rewards)),
        "mean_cumulative_loss": float(np.mean(episode_losses)),
        "mean_defense_cost": float(np.mean(episode_defense_costs)),
        "mean_attack_cost": float(np.mean(episode_attack_costs)),
        "attack_success_rate": float(attack_success_rate),
        "new_infections_per_episode": float(
            total_new_infections / config.eval_episodes
        ),
        "recoveries_per_episode": float(
            total_recoveries / config.eval_episodes
        ),
    }

    for i in range(config.K):
        metrics[f"attack_frequency_{i}"] = float(
            attacks_per_target[i] / total_attack_attempts
        )

    return metrics


# =========================================================
# 3. AGGREGATE RESULTS ACROSS SEEDS
# =========================================================


def aggregate_results(results: list[dict]) -> list[dict]:
    """Aggregate per-seed evaluation results by defender policy."""
    if not results:
        return []

    policy_names = list(dict.fromkeys(row["policy"] for row in results))
    metadata = {"policy", "training_seed", "evaluation_seed"}
    metric_names = [key for key in results[0] if key not in metadata]

    summaries = []
    for policy_name in policy_names:
        rows = [row for row in results if row["policy"] == policy_name]
        summary = {"policy": policy_name, "num_seeds": len(rows)}

        for metric in metric_names:
            values = np.asarray([row[metric] for row in rows], dtype=float)
            valid = values[~np.isnan(values)]
            if len(valid) == 0:
                mean = float("nan")
                std = float("nan")
            else:
                mean = float(np.mean(valid))
                std = float(np.std(valid, ddof=1)) if len(valid) > 1 else 0.0

            summary[f"{metric}_mean"] = mean
            summary[f"{metric}_std_across_seeds"] = std

        summaries.append(summary)

    return summaries


# =========================================================
# 4. PLOTTING
# =========================================================


def _moving_average(values: np.ndarray, window: int) -> tuple[np.ndarray, np.ndarray]:
    window = min(window, len(values))
    curve = np.convolve(
        values,
        np.ones(window, dtype=float) / window,
        mode="valid",
    )
    episodes = np.arange(window, len(values) + 1)
    return episodes, curve


def plot_learning_curves(histories: list[dict], output_dir: Path) -> None:
    """Plot training returns for both agents."""
    if plt is None:
        warnings.warn("Matplotlib is unavailable; skipping learning curves.")
        return
    if not histories:
        return

    output_dir.mkdir(parents=True, exist_ok=True)
    series = [
        (
            "defender_episode_return",
            "Defender discounted episode return",
            "defender_learning_curve.png",
        ),
        (
            "attacker_episode_return",
            "Attacker discounted episode return",
            "attacker_learning_curve.png",
        ),
    ]

    for key, ylabel, filename in series:
        curves = np.asarray([history[key] for history in histories], dtype=float)
        mean_curve = np.mean(curves, axis=0)
        episodes, moving_average = _moving_average(mean_curve, window=20)

        plt.figure(figsize=(9, 5))
        plt.plot(episodes, moving_average)
        plt.xlabel("Training episode")
        plt.ylabel(ylabel)
        plt.title(ylabel)
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / filename, dpi=160)
        plt.close()


def plot_policy_comparison(summary: list[dict], output_dir: Path) -> None:
    """Plot defender and attacker outcomes for each defender policy."""
    if plt is None or not summary:
        return

    output_dir.mkdir(parents=True, exist_ok=True)
    plots = [
        (
            "mean_discounted_return",
            "Mean defender discounted return",
            "policy_defender_returns.png",
        ),
        (
            "mean_discounted_attacker_return",
            "Mean attacker discounted return",
            "policy_attacker_returns.png",
        ),
        (
            "mean_cumulative_loss",
            "Mean cumulative infected-target loss",
            "policy_infected_loss.png",
        ),
        (
            "mean_defense_cost",
            "Mean cumulative defense cost",
            "policy_defense_cost.png",
        ),
    ]

    labels = [row["policy"].replace("_", " ") for row in summary]

    for metric, ylabel, filename in plots:
        means = np.asarray([row[f"{metric}_mean"] for row in summary], dtype=float)
        stds = np.asarray(
            [row[f"{metric}_std_across_seeds"] for row in summary],
            dtype=float,
        )
        stds = np.nan_to_num(stds, nan=0.0)

        plt.figure(figsize=(9, 5))
        plt.bar(labels, means, yerr=stds, capsize=4)
        plt.ylabel(ylabel)
        plt.xticks(rotation=15, ha="right")
        plt.title(ylabel)
        plt.grid(axis="y", alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / filename, dpi=160)
        plt.close()


# =========================================================
# 5. RUN THE COMPLETE EXPERIMENT
# =========================================================


def run_experiments(
    config: GameConfig,
    output_dir: Path = OUTPUT_DIR,
    make_plots: bool = True,
    save_checkpoints: bool = True,
) -> tuple[list[dict], list[dict], list[dict]]:
    """Train both agents, evaluate the learned pair and defender baselines.

    Every evaluated defender is paired with the RL attacker trained for
    that seed. The optional DP policy is the defender's best response to
    that seed's frozen greedy attacker policy, not a Nash equilibrium.
    """
    if not config.seeds:
        raise ValueError("At least one seed is required.")
    if config.eval_episodes <= 0 or config.eval_horizon <= 0:
        raise ValueError("Evaluation episodes and horizon must be positive.")

    output_dir = Path(output_dir)
    results_dir = output_dir / "results"
    checkpoints_dir = output_dir / "checkpoints"
    figures_dir = output_dir / "figures"

    results_dir.mkdir(parents=True, exist_ok=True)
    if save_checkpoints:
        checkpoints_dir.mkdir(parents=True, exist_ok=True)
    save_config(config, output_dir)

    base_env = SecurityGame(config, seed=config.seeds[0])
    states = base_env.states
    actions = base_env.actions
    state_to_index = {state: i for i, state in enumerate(states)}
    action_to_index = {action: i for i, action in enumerate(actions)}

    print("\nConfiguration")
    print("-------------")
    print(f"Targets:                 {config.K}")
    print(f"Defense budget:          {config.B}")
    print(f"States:                  {len(states)}")
    print(f"Defense actions:         {len(actions)}")
    print(f"Attacker actions:        {config.K}")
    print(f"Training seeds:          {len(config.seeds)}")
    print("Attacker observes defense: yes")

    attacker_contexts = len(states) * len(actions)
    attacker_entries = attacker_contexts * config.K
    attacker_table_mb = attacker_entries * np.dtype(np.float32).itemsize / (1024 ** 2)
    training_steps = config.num_episodes * config.steps_per_episode
    print(f"Attacker (state, defense) contexts: {attacker_contexts:,}")
    print(f"Attacker Q-table memory:            {attacker_table_mb:.1f} MiB")
    if attacker_contexts > 10 * training_steps:
        warnings.warn(
            "The attacker has far more (state, defense) contexts than "
            "training steps. Its tabular Q-function will be sparsely "
            "visited; increase training or reduce K / the defense action "
            "space before interpreting the learned policy as converged."
        )

    high_value_action = highest_value_policy(config, actions)
    even_action = uniform_policy(config)

    all_results = []
    training_histories = []

    for seed_idx, training_seed in enumerate(config.seeds):
        print(
            f"\nSeed {seed_idx + 1}/{len(config.seeds)}: {training_seed}"
        )

        train_env = SecurityGame(config, seed=training_seed)
        Q_defender, Q_attacker, history = train_multi_agent_q_learning(
            config=config,
            env=train_env,
            states=states,
            actions=actions,
            state_to_index=state_to_index,
            action_to_index=action_to_index,
            seed=training_seed,
        )
        training_histories.append(history)

        if save_checkpoints:
            np.savez_compressed(
                checkpoints_dir / f"multi_agent_q_seed_{training_seed}.npz",
                Q_defender=Q_defender,
                Q_attacker=Q_attacker,
                states=np.asarray(states, dtype=np.int8),
                actions=np.asarray(actions, dtype=np.int16),
            )

        learned_attacker: AttackerPolicyFunction = (
            lambda state, defense, q=Q_attacker: attacker_q_policy(
                state,
                defense,
                q,
                state_to_index,
                action_to_index,
            )
        )

        learned_defender: PolicyFunction = (
            lambda state, q=Q_defender: q_learning_policy(
                state,
                q,
                state_to_index,
                actions,
            )
        )

        policies: dict[str, PolicyFunction] = {
            "q_learning_defender": learned_defender,
            "highest_value": lambda state, action=high_value_action: action,
            "uniform": lambda state, action=even_action: action,
        }

        if config.run_best_response_dp:
            print("  Computing best-response DP against the learned attacker...")
            V_br, Q_br, best_response = solve_best_response_value_iteration(
                config=config,
                states=states,
                actions=actions,
                env=base_env,
                Q_attacker=Q_attacker,
                state_to_index=state_to_index,
                action_to_index=action_to_index,
            )
            policies["best_response_dp"] = (
                lambda state, policy=best_response: best_response_dp_policy(
                    state,
                    policy,
                    state_to_index,
                    actions,
                )
            )

            if save_checkpoints:
                np.savez_compressed(
                    checkpoints_dir / f"best_response_dp_seed_{training_seed}.npz",
                    V=V_br,
                    Q=Q_br,
                    policy=best_response,
                )

        evaluation_seed = int(training_seed) + 100000

        for policy_name, defender_policy in policies.items():
            print(f"  Evaluating {policy_name} against learned attacker...")
            metrics = evaluate_policy(
                config=config,
                defender_policy=defender_policy,
                attacker_policy=learned_attacker,
                seed=evaluation_seed,
            )

            all_results.append({
                "policy": policy_name,
                "training_seed": int(training_seed),
                "evaluation_seed": int(evaluation_seed),
                **metrics,
            })

    summary = aggregate_results(all_results)

    save_csv(results_dir / "results_by_seed.csv", all_results)
    save_csv(results_dir / "summary.csv", summary)

    if make_plots:
        plot_learning_curves(training_histories, figures_dir)
        plot_policy_comparison(summary, figures_dir)

    print("\nFinal results")
    print("=" * 112)
    print(
        f"{'Defender policy':<24}"
        f"{'Defender return':>19}"
        f"{'Attacker return':>19}"
        f"{'Infected loss':>19}"
        f"{'Defense cost':>19}"
    )
    print("-" * 112)

    for row in summary:
        print(
            f"{row['policy']:<24}"
            f"{row['mean_discounted_return_mean']:>19.4f}"
            f"{row['mean_discounted_attacker_return_mean']:>19.4f}"
            f"{row['mean_cumulative_loss_mean']:>19.4f}"
            f"{row['mean_defense_cost_mean']:>19.4f}"
        )

    print(f"\nResults saved to: {results_dir}")
    print(f"Figures saved to: {figures_dir}")

    return all_results, summary, training_histories


# =========================================================
# 6. OPTIONAL PARAMETER SWEEPS
# =========================================================


def run_parameter_sweep(
    config: GameConfig,
    parameter_grid: dict,
    output_dir: Path = OUTPUT_DIR,
) -> list[dict]:
    """Run the two-agent experiment for each parameter setting."""
    sweep_output_dir = Path(output_dir) / "parameter_sweeps"
    sweep_results = []

    for parameter, settings in parameter_grid.items():
        for setting_idx, setting in enumerate(settings):
            if isinstance(setting, dict):
                overrides = setting
                displayed_value = overrides.get(
                    parameter,
                    f"configuration_{setting_idx}",
                )
            else:
                overrides = {parameter: setting}
                displayed_value = setting

            variant_config = replace(config, **overrides)
            label = (
                f"{parameter}_{setting_idx:02d}_"
                f"{str(displayed_value).replace('.', 'p')}"
            )
            variant_output_dir = (
                sweep_output_dir / parameter / label
            )

            print(
                f"\nParameter sweep: {parameter} = {displayed_value}"
            )
            _, variant_summary, _ = run_experiments(
                config=variant_config,
                output_dir=variant_output_dir,
                make_plots=False,
                save_checkpoints=False,
            )

            try:
                numeric_value = float(displayed_value)
            except (TypeError, ValueError):
                numeric_value = float("nan")

            for row in variant_summary:
                sweep_results.append({
                    "sweep_parameter": parameter,
                    "sweep_value": str(displayed_value),
                    "sweep_value_numeric": numeric_value,
                    "policy": row["policy"],
                    "mean_discounted_return": row[
                        "mean_discounted_return_mean"
                    ],
                    "mean_discounted_attacker_return": row[
                        "mean_discounted_attacker_return_mean"
                    ],
                    "mean_cumulative_loss": row[
                        "mean_cumulative_loss_mean"
                    ],
                    "mean_defense_cost": row[
                        "mean_defense_cost_mean"
                    ],
                })

    save_csv(
        sweep_output_dir / "parameter_sweep_summary.csv",
        sweep_results,
    )
    plot_parameter_sweep(sweep_results, sweep_output_dir)
    return sweep_results


def plot_parameter_sweep(
    sweep_results: list[dict],
    output_dir: Path,
) -> None:
    """Plot defender return against numeric sweep parameters."""
    if plt is None or not sweep_results:
        return

    output_dir.mkdir(parents=True, exist_ok=True)
    parameters = list(dict.fromkeys(
        row["sweep_parameter"] for row in sweep_results
    ))

    for parameter in parameters:
        rows = [
            row for row in sweep_results
            if row["sweep_parameter"] == parameter
            and np.isfinite(row["sweep_value_numeric"])
        ]
        if not rows:
            continue

        plt.figure(figsize=(9, 5))
        policies = list(dict.fromkeys(row["policy"] for row in rows))

        for policy in policies:
            policy_rows = sorted(
                [row for row in rows if row["policy"] == policy],
                key=lambda row: row["sweep_value_numeric"],
            )
            x = [row["sweep_value_numeric"] for row in policy_rows]
            y = [row["mean_discounted_return"] for row in policy_rows]
            plt.plot(x, y, marker="o", label=policy.replace("_", " "))

        plt.xlabel(parameter)
        plt.ylabel("Mean defender discounted return")
        plt.title(f"Parameter sweep: {parameter}")
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / f"{parameter}_return.png", dpi=160)
        plt.close()


# =========================================================
# 7. ENTRY POINT
# =========================================================


def main() -> None:
    run_experiments(CONFIG)

    if RUN_PARAMETER_SWEEPS and PARAMETER_SWEEP:
        run_parameter_sweep(CONFIG, PARAMETER_SWEEP)


if __name__ == "__main__":
    main()
