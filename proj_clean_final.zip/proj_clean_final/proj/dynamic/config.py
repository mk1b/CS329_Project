# config.py

from dataclasses import dataclass
from pathlib import Path


@dataclass
class GameConfig:
    # =============================================
    # Game parameters
    # =============================================

    K: int = 5
    B: int = 2

    eta: float = 0.20
    defense_cost_lambda: float = 0.75
    gamma: float = 0.95

    # Per-target parameters: all must have length K.
    values: tuple[float, ...] = (
        10.0, 8.0, 6.0, 4.0, 3.0
    )

    attack_probs: tuple[float, ...] = (
        0.60, 0.55, 0.45, 0.35, 0.30
    )

    attack_costs: tuple[float, ...] = (
        1.0, 1.0, 1.0, 1.0, 1.0
    )

    recovery_probs: tuple[float, ...] = (
        0.20, 0.15, 0.25, 0.30, 0.20
    )

    # None means all targets start healthy.
    initial_state: tuple[int, ...] | None = None

    # =============================================
    # Defender Q-learning parameters
    # =============================================

    num_episodes: int = 500
    steps_per_episode: int = 100

    alpha: float = 0.10
    epsilon_start: float = 1.0
    epsilon_min: float = 0.05
    epsilon_decay_steps: int = 10000	#num_ep*20

    # =============================================
    # Attacker Q-learning parameters
    # =============================================

    attacker_alpha: float = 0.10
    attacker_epsilon_start: float = 1.0
    attacker_epsilon_min: float = 0.05
    attacker_epsilon_decay_steps: int = 10000

    # =============================================
    # Optional exact best-response benchmark
    # =============================================

    # This solves the defender's MDP against the frozen greedy
    # policy of the trained attacker. It is useful for small K,
    # but can be expensive for large state/action spaces.
    run_best_response_dp: bool = False
    dp_tolerance: float = 1e-8
    dp_max_iterations: int = 10000

    # =============================================
    # Evaluation parameters
    # =============================================

    eval_episodes: int = 1000
    eval_horizon: int = 100

    seeds: tuple[int, ...] = (
        42,
        169,
        6969,
        696969
    )


# =============================================
# Main configuration
# =============================================

CONFIG = GameConfig()


# =============================================
# Output directories
# =============================================

OUTPUT_DIR = Path("outputs")
RESULTS_DIR = OUTPUT_DIR / "results"
CHECKPOINTS_DIR = OUTPUT_DIR / "checkpoints"
FIGURES_DIR = OUTPUT_DIR / "figures"


# =============================================
# Optional parameter sweeps
# =============================================

RUN_PARAMETER_SWEEPS = False

PARAMETER_SWEEP = {
    "B": (1, 2, 3),
    "eta": (0.10, 0.20, 0.30),
    "defense_cost_lambda": (0.25, 0.75, 1.50),
}
