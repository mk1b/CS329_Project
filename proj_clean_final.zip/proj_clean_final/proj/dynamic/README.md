# Two-agent RL security game

This folder contains the four runnable Python modules:

- `config.py`: game, training, evaluation, and optional DP settings.
- `game.py`: environment with explicit defender and attacker actions.
- `algorithms.py`: independent tabular Q-learning agents and policy helpers.
- `main.py`: training, evaluation, CSV/checkpoint output, plots, and sweeps.

Run with:

```bash
python main.py
```

Dependencies: `numpy`; `matplotlib` is optional and only used for plots.

## Turn order and state representation

On each turn the defender observes infection state `s` and chooses allocation
`d`. The attacker then observes `(s, d)` and chooses target `i`. The Q tables
are therefore:

- Defender: `Q_defender[s, d]`
- Attacker: `Q_attacker[s, d, i]`

The attacker receives `target_value` when it newly infects a healthy target,
minus that target's attack cost. Its expected immediate reward is therefore
`value[i] * (1 - s[i]) * infection_probability(i, d) - attack_cost[i]`.
The defender reward remains `-infected_value(s) - defense_cost(d)`.

The agents are independently learning in a general-sum stochastic game.
Because both policies change during training, standard single-agent Q-learning
convergence guarantees do not apply to the joint training process.

## Optional DP benchmark

Set `run_best_response_dp=True` in `config.py` to compute the defender's exact
best response to the frozen greedy policy of the trained attacker. This is a
best-response benchmark, not a Nash equilibrium. It can be expensive for large
`K`; it is disabled by default.
