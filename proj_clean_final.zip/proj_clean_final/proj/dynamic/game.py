# game.py

from itertools import product
import numpy as np

from config import GameConfig

State = tuple[int, ...]
DefenseAction = tuple[int, ...]
AttackAction = int


def enumerate_states(K: int) -> list[State]:
    """Generate all 2^K possible infection states."""
    return list(product((0, 1), repeat=K))


def generate_actions(K: int, B: int) -> list[DefenseAction]:
    """Generate all integer allocations with total budget <= B."""
    actions = []

    def generate(i, remaining, current):
        if i == K:
            actions.append(tuple(current))
            return

        for amount in range(remaining + 1):
            current.append(amount)
            generate(i + 1, remaining - amount, current)
            current.pop()

    generate(0, B, [])
    return actions


class SecurityGame:
    """Security game with explicit defender and attacker actions.

    Within each turn:
      1. The defender observes the infection state and chooses an allocation.
      2. The attacker observes both the infection state and that allocation,
         then chooses one target.
      3. The attack outcome and recoveries determine the next state.

    The attacker is no longer selected by a hard-coded best-response rule.
    Its target is supplied by the learning agent through step().
    """

    def __init__(self, config: GameConfig, seed: int = 42):
        self.config = config
        self.rng = np.random.default_rng(seed)

        self.K = config.K
        self.B = config.B

        self.states = enumerate_states(self.K)
        self.actions = generate_actions(self.K, self.B)

        self.state = tuple(
            config.initial_state
            if config.initial_state is not None
            else (0,) * self.K
        )

        self._validate_config()
        self._validate_state(self.state)

    # --------------------------------------------------
    # Validation
    # --------------------------------------------------

    def _validate_config(self):
        c = self.config

        if self.K < 1 or self.B < 0:
            raise ValueError("K must be positive and B nonnegative.")

        if len(c.values) != self.K:
            raise ValueError("values must have length K.")
        if len(c.attack_probs) != self.K:
            raise ValueError("attack_probs must have length K.")
        if len(c.attack_costs) != self.K:
            raise ValueError("attack_costs must have length K.")
        if len(c.recovery_probs) != self.K:
            raise ValueError("recovery_probs must have length K.")

        if not 0 < c.eta < 1:
            raise ValueError("eta must lie in (0, 1).")
        if not 0 < c.gamma < 1:
            raise ValueError("gamma must lie in (0, 1).")
        if any(v <= 0 for v in c.values):
            raise ValueError("Target values must be positive.")
        if any(cost <= 0 for cost in c.attack_costs):
            raise ValueError("Attack costs must be positive.")
        if any(not 0 <= p <= 1 for p in c.attack_probs):
            raise ValueError("Attack probabilities must lie in [0, 1].")
        if any(not 0 <= r <= 1 for r in c.recovery_probs):
            raise ValueError("Recovery probabilities must lie in [0, 1].")
        if c.defense_cost_lambda < 0:
            raise ValueError("Defense cost must be nonnegative.")

    def _validate_state(self, state: State):
        if len(state) != self.K or any(x not in (0, 1) for x in state):
            raise ValueError("Invalid state.")

    def is_valid_action(self, defense: DefenseAction) -> bool:
        return (
            len(defense) == self.K
            and all(
                isinstance(d, (int, np.integer)) and 0 <= d <= self.B
                for d in defense
            )
            and sum(defense) <= self.B
        )

    def is_valid_attack(self, attack_target: AttackAction) -> bool:
        return (
            isinstance(attack_target, (int, np.integer))
            and 0 <= int(attack_target) < self.K
        )

    # --------------------------------------------------
    # Game model and rewards
    # --------------------------------------------------

    def infection_probability(
        self,
        target: int,
        defense: DefenseAction,
    ) -> float:
        """q_i(d_i) = p_i * (1 - eta)^d_i."""
        return (
            self.config.attack_probs[target]
            * (1 - self.config.eta) ** defense[target]
        )

    def defender_loss(self, state: State) -> float:
        """Weighted value of currently infected targets."""
        return sum(
            self.config.values[i] * state[i]
            for i in range(self.K)
        )

    def defense_cost(self, defense: DefenseAction) -> float:
        return self.config.defense_cost_lambda * sum(defense)

    def defender_reward(
        self,
        state: State,
        defense: DefenseAction,
    ) -> float:
        """R_D(x,d) = -L(x) - C_D(d)."""
        return -self.defender_loss(state) - self.defense_cost(defense)

    def attacker_reward(
        self,
        state: State,
        attack_target: int,
        new_infection: bool,
    ) -> float:
        """R_A = target value for a new infection minus attack cost.

        Its expectation, conditional on (state, defense, target), is
        V_i * (1 - state_i) * q_i(d_i) - attack_cost_i, matching the
        one-step utility expression used by the previous attacker model.
        """
        infection_value = (
            self.config.values[attack_target]
            if state[attack_target] == 0 and new_infection
            else 0.0
        )
        return infection_value - self.config.attack_costs[attack_target]

    # --------------------------------------------------
    # Exact transition distribution (for optional model-based DP)
    # --------------------------------------------------

    def transition_distribution(
        self,
        state: State,
        defense: DefenseAction,
        attack_target: int,
    ) -> dict[State, float]:
        """Return {next_state: probability} for fixed joint actions."""

        self._validate_state(state)
        defense = tuple(defense)

        if not self.is_valid_action(defense):
            raise ValueError("Invalid defense allocation.")
        if not self.is_valid_attack(attack_target):
            raise ValueError("Invalid attack target.")

        attack_target = int(attack_target)
        distribution = {}

        for next_state in self.states:
            probability = 1.0

            for i in range(self.K):
                current = state[i]
                nxt = next_state[i]

                if current == 1:
                    rho = self.config.recovery_probs[i]
                    p_i = rho if nxt == 0 else 1 - rho
                elif i == attack_target:
                    q = self.infection_probability(i, defense)
                    p_i = q if nxt == 1 else 1 - q
                else:
                    p_i = 1.0 if nxt == 0 else 0.0

                probability *= p_i
                if probability == 0:
                    break

            if probability > 0:
                distribution[next_state] = probability

        return distribution

    # --------------------------------------------------
    # Reset and simulation
    # --------------------------------------------------

    def reset(self, initial_state: State | None = None) -> State:
        """Reset the state without resetting the random generator."""
        if initial_state is None:
            initial_state = (
                self.config.initial_state
                if self.config.initial_state is not None
                else (0,) * self.K
            )

        initial_state = tuple(initial_state)
        self._validate_state(initial_state)
        self.state = initial_state
        return self.state

    def step(
        self,
        defense: DefenseAction,
        attack_target: int,
    ) -> tuple[State, float, dict]:
        """Execute one turn using the two agents' selected actions.

        Returns (next_state, defender_reward, info). The attacker's reward
        is included in info["attacker_reward"].
        """
        defense = tuple(defense)

        if not self.is_valid_action(defense):
            raise ValueError(f"Invalid defense allocation: {defense}")
        if not self.is_valid_attack(attack_target):
            raise ValueError(f"Invalid attack target: {attack_target}")

        attack_target = int(attack_target)
        state_before = self.state

        defender_reward = self.defender_reward(state_before, defense)
        attack_probability = self.infection_probability(
            attack_target,
            defense,
        )

        attack_roll_success = self.rng.random() < attack_probability

        next_state = list(state_before)
        new_infection = False

        if state_before[attack_target] == 0 and attack_roll_success:
            next_state[attack_target] = 1
            new_infection = True

        # Targets infected at the beginning of this turn may recover.
        recovered_targets = []
        for i in range(self.K):
            if state_before[i] == 1:
                if self.rng.random() < self.config.recovery_probs[i]:
                    next_state[i] = 0
                    recovered_targets.append(i)

        self.state = tuple(next_state)
        attacker_reward = self.attacker_reward(
            state_before,
            attack_target,
            new_infection,
        )

        info = {
            "state_before": state_before,
            "defense": defense,
            "attack_target": attack_target,
            "attack_probability": attack_probability,
            "attack_roll_success": bool(attack_roll_success),
            "new_infection": new_infection,
            "attacker_reward": attacker_reward,
            "recovered_targets": recovered_targets,
            "state_after": self.state,
            "infected_value": self.defender_loss(state_before),
            "defense_cost": self.defense_cost(defense),
            "attack_cost": self.config.attack_costs[attack_target],
        }

        return self.state, defender_reward, info
