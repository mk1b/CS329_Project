# algorithms.py

import warnings
import numpy as np

from config import GameConfig
from game import SecurityGame, State, DefenseAction


# =========================================================
# 1. EPSILON-GREEDY EXPLORATION
# =========================================================


def epsilon_at_step(
    global_step: int,
    config: GameConfig,
    agent: str = "defender",
) -> float:
    """Linearly decay the selected agent's exploration rate."""
    if agent == "defender":
        start = config.epsilon_start
        minimum = config.epsilon_min
        decay_steps = config.epsilon_decay_steps
    elif agent == "attacker":
        start = config.attacker_epsilon_start
        minimum = config.attacker_epsilon_min
        decay_steps = config.attacker_epsilon_decay_steps
    else:
        raise ValueError("agent must be 'defender' or 'attacker'.")

    if not 0 <= minimum <= start <= 1:
        raise ValueError(
            f"Require 0 <= {agent} epsilon_min <= epsilon_start <= 1."
        )
    if decay_steps <= 0:
        raise ValueError(f"{agent} epsilon_decay_steps must be positive.")

    fraction = min(global_step / decay_steps, 1.0)
    return start - fraction * (start - minimum)


# =========================================================
# 2. ACTION SELECTION
# =========================================================


def select_defender_action(
    state: State,
    Q_defender: np.ndarray,
    state_to_index: dict[State, int],
    actions: list[DefenseAction],
    epsilon: float,
    rng: np.random.Generator,
) -> tuple[int, DefenseAction]:
    """Select a defense allocation using epsilon-greedy exploration."""
    state_idx = state_to_index[state]

    if rng.random() < epsilon:
        action_idx = int(rng.integers(len(actions)))
    else:
        action_idx = int(np.argmax(Q_defender[state_idx]))

    return action_idx, actions[action_idx]


def select_attacker_action(
    state_idx: int,
    defense_idx: int,
    Q_attacker: np.ndarray,
    epsilon: float,
    rng: np.random.Generator,
) -> int:
    """Select a target after observing the defender's allocation.

    Q_attacker[state, defense_action, target] stores the attacker's
    action values. The attacker controls only the target, not the defense.
    """
    num_targets = Q_attacker.shape[2]

    if rng.random() < epsilon:
        return int(rng.integers(num_targets))

    return int(np.argmax(Q_attacker[state_idx, defense_idx]))


# =========================================================
# 3. TWO-AGENT TABULAR Q-LEARNING
# =========================================================


def train_multi_agent_q_learning(
    config: GameConfig,
    env: SecurityGame,
    states: list[State],
    actions: list[DefenseAction],
    state_to_index: dict[State, int] | None = None,
    action_to_index: dict[DefenseAction, int] | None = None,
    seed: int = 42,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """Train a Q-learning defender and a Q-learning attacker.

    Defender state/action:
        Q_D[s, d]

    Attacker observation/action:
        Q_A[s, d, i]

    The attacker sees the defense allocation before choosing its target.
    Its next-state bootstrap averages over the defender's current
    epsilon-greedy action distribution, then maximizes over attack targets.
    This respects the fact that the attacker does not choose the next defense.

    The two learners are independent learners in a general-sum stochastic
    game. Their policies change during training, so the usual single-agent
    Q-learning convergence guarantee does not apply to the joint process.

    Returns:
        Q_defender, Q_attacker, training_history
    """
    if not states or not actions:
        raise ValueError("States and actions must be nonempty.")
    if not 0 < config.alpha <= 1:
        raise ValueError("alpha must lie in (0, 1].")
    if not 0 < config.attacker_alpha <= 1:
        raise ValueError("attacker_alpha must lie in (0, 1].")
    if config.num_episodes <= 0 or config.steps_per_episode <= 0:
        raise ValueError("Training episodes and steps must be positive.")

    if state_to_index is None:
        state_to_index = {state: i for i, state in enumerate(states)}
    if action_to_index is None:
        action_to_index = {action: i for i, action in enumerate(actions)}

    num_states = len(states)
    num_defense_actions = len(actions)
    num_targets = config.K

    # Separate random stream for policy exploration; env owns transition RNG.
    rng = np.random.default_rng(seed + 1)
    env.rng = np.random.default_rng(seed)

    # float32 halves memory use for the (state, defense, target) table.
    Q_defender = np.zeros(
        (num_states, num_defense_actions),
        dtype=np.float32,
    )
    Q_attacker = np.zeros(
        (num_states, num_defense_actions, num_targets),
        dtype=np.float32,
    )

    defender_visits = np.zeros(
        (num_states, num_defense_actions),
        dtype=np.uint32,
    )

    gamma = config.gamma
    defender_alpha = config.alpha
    attacker_alpha = config.attacker_alpha

    history = {
        "episode": [],
        "defender_episode_return": [],
        "attacker_episode_return": [],
        "defender_episode_reward": [],
        "attacker_episode_reward": [],
        "cumulative_loss": [],
        "defense_cost": [],
        "mean_defender_epsilon": [],
        "mean_attacker_epsilon": [],
        "mean_abs_defender_td_error": [],
        "mean_abs_attacker_td_error": [],
    }

    global_step = 0

    for episode in range(config.num_episodes):
        state = env.reset()

        defender_return = 0.0
        attacker_return = 0.0
        defender_reward_sum = 0.0
        attacker_reward_sum = 0.0
        cumulative_loss = 0.0
        defense_cost_sum = 0.0

        defender_epsilon_sum = 0.0
        attacker_epsilon_sum = 0.0
        defender_td_error_sum = 0.0
        attacker_td_error_sum = 0.0

        for step in range(config.steps_per_episode):
            state_idx = state_to_index[state]

            # A. Defender chooses an allocation.
            epsilon_defender = epsilon_at_step(
                global_step,
                config,
                agent="defender",
            )
            defense_idx, defense = select_defender_action(
                state=state,
                Q_defender=Q_defender,
                state_to_index=state_to_index,
                actions=actions,
                epsilon=epsilon_defender,
                rng=rng,
            )

            # B. Attacker observes the allocation and chooses a target.
            epsilon_attacker = epsilon_at_step(
                global_step,
                config,
                agent="attacker",
            )
            attack_target = select_attacker_action(
                state_idx=state_idx,
                defense_idx=defense_idx,
                Q_attacker=Q_attacker,
                epsilon=epsilon_attacker,
                rng=rng,
            )

            # C. Execute both actions in the environment.
            next_state, defender_reward, info = env.step(
                defense,
                attack_target,
            )
            next_state_idx = state_to_index[next_state]
            attacker_reward = float(info["attacker_reward"])

            # D. Update the defender. The attacker is part of the
            # transition dynamics; Q-learning bootstraps over future defenses.
            defender_visits[state_idx, defense_idx] += 1
            defender_td_target = (
                defender_reward
                + gamma * float(np.max(Q_defender[next_state_idx]))
            )
            defender_td_error = (
                defender_td_target
                - float(Q_defender[state_idx, defense_idx])
            )
            Q_defender[state_idx, defense_idx] += (
                defender_alpha * defender_td_error
            )

            # E. Update the attacker. At the next turn, the defender first
            # chooses an allocation. Average the attacker's best continuation
            # value over that epsilon-greedy defender action distribution.
            next_defender_epsilon = epsilon_at_step(
                global_step + 1,
                config,
                agent="defender",
            )
            next_attack_values = np.max(
                Q_attacker[next_state_idx],
                axis=1,
            )
            next_greedy_defense_idx = int(
                np.argmax(Q_defender[next_state_idx])
            )
            expected_next_attacker_value = (
                (1.0 - next_defender_epsilon)
                * float(next_attack_values[next_greedy_defense_idx])
                + next_defender_epsilon
                * float(np.mean(next_attack_values))
            )

            attacker_td_target = (
                attacker_reward
                + gamma * expected_next_attacker_value
            )
            attacker_td_error = (
                attacker_td_target
                - float(Q_attacker[state_idx, defense_idx, attack_target])
            )
            Q_attacker[state_idx, defense_idx, attack_target] += (
                attacker_alpha * attacker_td_error
            )

            # F. Episode statistics.
            discount = gamma ** step
            defender_return += discount * defender_reward
            attacker_return += discount * attacker_reward
            defender_reward_sum += defender_reward
            attacker_reward_sum += attacker_reward
            cumulative_loss += info["infected_value"]
            defense_cost_sum += info["defense_cost"]

            defender_epsilon_sum += epsilon_defender
            attacker_epsilon_sum += epsilon_attacker
            defender_td_error_sum += abs(defender_td_error)
            attacker_td_error_sum += abs(attacker_td_error)

            state = next_state
            global_step += 1

        history["episode"].append(episode + 1)
        history["defender_episode_return"].append(defender_return)
        history["attacker_episode_return"].append(attacker_return)
        history["defender_episode_reward"].append(defender_reward_sum)
        history["attacker_episode_reward"].append(attacker_reward_sum)
        history["cumulative_loss"].append(cumulative_loss)
        history["defense_cost"].append(defense_cost_sum)
        history["mean_defender_epsilon"].append(
            defender_epsilon_sum / config.steps_per_episode
        )
        history["mean_attacker_epsilon"].append(
            attacker_epsilon_sum / config.steps_per_episode
        )
        history["mean_abs_defender_td_error"].append(
            defender_td_error_sum / config.steps_per_episode
        )
        history["mean_abs_attacker_td_error"].append(
            attacker_td_error_sum / config.steps_per_episode
        )

    history["defender_visits"] = defender_visits
    history["seed"] = seed
    history["training_steps"] = global_step

    return Q_defender, Q_attacker, history


# =========================================================
# 4. LEARNED POLICIES
# =========================================================


def extract_q_policy(Q: np.ndarray) -> np.ndarray:
    """Return greedy action indices for a 2D state-action table."""
    if Q.ndim != 2 or Q.shape[1] == 0:
        raise ValueError("Q must be 2D with at least one action.")
    return np.argmax(Q, axis=1)


def q_learning_policy(
    state: State,
    Q_defender: np.ndarray,
    state_to_index: dict[State, int],
    actions: list[DefenseAction],
) -> DefenseAction:
    """Return the greedy defense allocation learned by the defender."""
    state_idx = state_to_index[state]
    action_idx = int(np.argmax(Q_defender[state_idx]))
    return actions[action_idx]


def attacker_q_policy(
    state: State,
    defense: DefenseAction,
    Q_attacker: np.ndarray,
    state_to_index: dict[State, int],
    action_to_index: dict[DefenseAction, int],
) -> int:
    """Return the greedy attack target for the observed (state, defense)."""
    state_idx = state_to_index[state]
    defense_idx = action_to_index[tuple(defense)]
    return int(np.argmax(Q_attacker[state_idx, defense_idx]))


def greedy_attacker_policy(
    config: GameConfig,
    state: State,
    defense: DefenseAction,
) -> int:
    """Return the original one-step utility-maximizing attack target.

    This exactly reproduces the static attacker from the original game:
        U_i = v_i * (1 - state_i) * p_i * (1 - eta) ** defense_i - c_i

    Ties are broken by the smallest target index, matching Python's
    max(range(K), key=...) behaviour in the original implementation.
    """
    utilities = [
        config.values[i]
        * (1 - state[i])
        * config.attack_probs[i]
        * (1 - config.eta) ** defense[i]
        - config.attack_costs[i]
        for i in range(config.K)
    ]
    return max(range(config.K), key=lambda i: utilities[i])


# =========================================================
# 5. OPTIONAL BEST-RESPONSE DYNAMIC PROGRAMMING
# =========================================================


def solve_best_response_value_iteration(
    config: GameConfig,
    states: list[State],
    actions: list[DefenseAction],
    env: SecurityGame,
    Q_attacker: np.ndarray,
    state_to_index: dict[State, int] | None = None,
    action_to_index: dict[DefenseAction, int] | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Solve the defender's MDP against a frozen greedy RL attacker.

    For every (state, defense allocation), the attacker target is
    argmax_i Q_attacker[state, defense, i]. Value iteration then finds
    the defender's best response to that fixed attacker policy.

    This is NOT a Nash equilibrium of the two-agent game. It is a useful
    model-based benchmark against the learned attacker's frozen policy.
    """
    if state_to_index is None:
        state_to_index = {state: i for i, state in enumerate(states)}
    if action_to_index is None:
        action_to_index = {action: i for i, action in enumerate(actions)}

    num_states = len(states)
    num_actions = len(actions)
    rewards = np.zeros((num_states, num_actions), dtype=np.float64)
    transitions = [[None for _ in range(num_actions)] for _ in range(num_states)]

    for state_idx, state in enumerate(states):
        for defense_idx, defense in enumerate(actions):
            attack_target = int(
                np.argmax(Q_attacker[state_idx, defense_idx])
            )
            rewards[state_idx, defense_idx] = env.defender_reward(
                state,
                defense,
            )
            distribution = env.transition_distribution(
                state,
                defense,
                attack_target,
            )
            probability_sum = sum(distribution.values())
            if not np.isclose(probability_sum, 1.0):
                raise ValueError(
                    f"Transition probabilities sum to {probability_sum}, not 1."
                )
            transitions[state_idx][defense_idx] = [
                (state_to_index[next_state], probability)
                for next_state, probability in distribution.items()
            ]

    value = np.zeros(num_states, dtype=np.float64)
    converged = False

    for _ in range(config.dp_max_iterations):
        new_value = np.empty_like(value)
        for state_idx in range(num_states):
            best_value = -np.inf
            for defense_idx in range(num_actions):
                expected_future = sum(
                    probability * value[next_idx]
                    for next_idx, probability
                    in transitions[state_idx][defense_idx]
                )
                candidate = (
                    rewards[state_idx, defense_idx]
                    + config.gamma * expected_future
                )
                best_value = max(best_value, candidate)
            new_value[state_idx] = best_value

        delta = float(np.max(np.abs(new_value - value)))
        value = new_value
        if delta < config.dp_tolerance:
            converged = True
            break

    if not converged:
        warnings.warn(
            "Best-response value iteration reached dp_max_iterations "
            "without meeting dp_tolerance."
        )

    Q_dp = np.empty((num_states, num_actions), dtype=np.float64)
    for state_idx in range(num_states):
        for defense_idx in range(num_actions):
            expected_future = sum(
                probability * value[next_idx]
                for next_idx, probability
                in transitions[state_idx][defense_idx]
            )
            Q_dp[state_idx, defense_idx] = (
                rewards[state_idx, defense_idx]
                + config.gamma * expected_future
            )

    best_response_policy = np.argmax(Q_dp, axis=1)
    return value, Q_dp, best_response_policy


def best_response_dp_policy(
    state: State,
    best_response_policy: np.ndarray,
    state_to_index: dict[State, int],
    actions: list[DefenseAction],
) -> DefenseAction:
    state_idx = state_to_index[state]
    return actions[int(best_response_policy[state_idx])]


# =========================================================
# 6. DEFENDER HEURISTIC BASELINES
# =========================================================


def highest_value_policy(
    config: GameConfig,
    actions: list[DefenseAction] | None = None,
) -> DefenseAction:
    """Allocate units in rounds ordered by descending target value."""
    order = sorted(
        range(config.K),
        key=lambda i: (-config.values[i], i),
    )

    defense = [0] * config.K
    for unit in range(config.B):
        target = order[unit % config.K]
        defense[target] += 1

    return tuple(defense)


def uniform_policy(config: GameConfig) -> DefenseAction:
    """Distribute B units as evenly as possible across K targets."""
    base = config.B // config.K
    remainder = config.B % config.K
    return tuple(
        base + (1 if i < remainder else 0)
        for i in range(config.K)
    )
