"""Evaluate previously trained RL defenders against the original greedy attacker.

Run from this directory:
    python evaluate_greedy.py

The script loads Q_defender from each multi-agent checkpoint. It does not
retrain either agent and does not use Q_attacker during evaluation.
"""

from pathlib import Path

import numpy as np

from config import CONFIG, OUTPUT_DIR
from game import SecurityGame
from algorithms import q_learning_policy, greedy_attacker_policy
from main import aggregate_results, evaluate_policy, save_csv


def main() -> None:
    env = SecurityGame(CONFIG, seed=CONFIG.seeds[0])
    states = env.states
    actions = env.actions

    state_to_index = {state: i for i, state in enumerate(states)}
    expected_states = np.asarray(states, dtype=np.int8)
    expected_actions = np.asarray(actions, dtype=np.int16)

    checkpoint_dir = Path(OUTPUT_DIR) / "checkpoints"
    results_dir = Path(OUTPUT_DIR) / "results"
    results_dir.mkdir(parents=True, exist_ok=True)

    rows = []

    for training_seed in CONFIG.seeds:
        checkpoint_path = (
            checkpoint_dir / f"multi_agent_q_seed_{training_seed}.npz"
        )
        if not checkpoint_path.exists():
            raise FileNotFoundError(
                f"Missing checkpoint: {checkpoint_path}. "
                "Train the agents first or correct OUTPUT_DIR."
            )

        with np.load(checkpoint_path) as checkpoint:
            if not np.array_equal(checkpoint["states"], expected_states):
                raise ValueError(
                    f"State space in {checkpoint_path} does not match CONFIG."
                )
            if not np.array_equal(checkpoint["actions"], expected_actions):
                raise ValueError(
                    f"Defense action space in {checkpoint_path} does not match CONFIG."
                )

            Q_defender = checkpoint["Q_defender"].copy()

        if Q_defender.shape != (len(states), len(actions)):
            raise ValueError(
                f"Unexpected Q_defender shape in {checkpoint_path}: "
                f"{Q_defender.shape}"
            )

        # Frozen defender: greedy action from its saved Q-table.
        defender_policy = (
            lambda state, q=Q_defender: q_learning_policy(
                state,
                q,
                state_to_index,
                actions,
            )
        )

        # Original static attacker: recomputes the immediate-utility
        # maximizing target from the current state and defense allocation.
        attacker_policy = (
            lambda state, defense: greedy_attacker_policy(
                CONFIG,
                state,
                defense,
            )
        )

        evaluation_seed = int(training_seed) + 100000
        print(
            f"Evaluating defender checkpoint {training_seed} "
            f"against greedy attacker (evaluation seed {evaluation_seed})..."
        )

        metrics = evaluate_policy(
            config=CONFIG,
            defender_policy=defender_policy,
            attacker_policy=attacker_policy,
            seed=evaluation_seed,
        )

        rows.append({
            "policy": "q_learning_defender_vs_greedy_attacker",
            "training_seed": int(training_seed),
            "evaluation_seed": int(evaluation_seed),
            **metrics,
        })

    summary = aggregate_results(rows)
    save_csv(
        results_dir / "rl_defender_vs_greedy_attacker_by_seed.csv",
        rows,
    )
    save_csv(
        results_dir / "rl_defender_vs_greedy_attacker_summary.csv",
        summary,
    )

    print("\nGreedy-attacker evaluation")
    print("--------------------------")
    for row in summary:
        print(
            f"Defender return: {row['mean_discounted_return_mean']:.4f} "
            f"+/- {row['mean_discounted_return_std_across_seeds']:.4f}"
        )
        print(
            f"Attacker return: {row['mean_discounted_attacker_return_mean']:.4f} "
            f"+/- {row['mean_discounted_attacker_return_std_across_seeds']:.4f}"
        )
        print(
            f"Infected loss:   {row['mean_cumulative_loss_mean']:.4f} "
            f"+/- {row['mean_cumulative_loss_std_across_seeds']:.4f}"
        )
        print(
            f"Attack success:  {row['attack_success_rate_mean']:.4f} "
            f"+/- {row['attack_success_rate_std_across_seeds']:.4f}"
        )

    print(f"\nPer-seed results: {results_dir / 'rl_defender_vs_greedy_attacker_by_seed.csv'}")
    print(f"Summary:          {results_dir / 'rl_defender_vs_greedy_attacker_summary.csv'}")


if __name__ == "__main__":
    main()
