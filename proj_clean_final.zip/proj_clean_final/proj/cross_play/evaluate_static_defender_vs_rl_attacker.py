"""Evaluate static-attacker-trained RL defenders against frozen RL attackers.

The defender checkpoint is produced by the original single-agent Q-learning
experiment, where SecurityGame.step() selected the original greedy attacker.
The attacker checkpoint is produced by the newer two-agent Q-learning run.

Example:
    python evaluate_static_defender_vs_rl_attacker.py \
        --static-defender-dir outputs_static/checkpoints \
        --rl-attacker-dir outputs/checkpoints

No learning occurs during this evaluation: both policies are frozen.
"""

import argparse
from pathlib import Path

import numpy as np

from config import CONFIG, OUTPUT_DIR
from game import SecurityGame
from algorithms import attacker_q_policy, q_learning_policy
from main import aggregate_results, evaluate_policy, save_csv


def load_and_validate_checkpoint(
    path: Path,
    expected_states: np.ndarray,
    expected_actions: np.ndarray,
    q_key: str,
) -> np.ndarray:
    """Load a Q-table after validating its state/action ordering."""
    if not path.exists():
        raise FileNotFoundError(f"Missing checkpoint: {path}")

    with np.load(path) as checkpoint:
        required = {"states", "actions", q_key}
        missing = required.difference(checkpoint.files)
        if missing:
            raise ValueError(
                f"Checkpoint {path} is missing required arrays: "
                f"{sorted(missing)}"
            )

        if not np.array_equal(checkpoint["states"], expected_states):
            raise ValueError(
                f"State space/order in {path} does not match CONFIG. "
                "Use the same K and initial game definition as training."
            )
        if not np.array_equal(checkpoint["actions"], expected_actions):
            raise ValueError(
                f"Defense action space/order in {path} does not match CONFIG. "
                "Use the same K and B as training."
            )

        return checkpoint[q_key].copy()


def main() -> None:
    # ================= CONFIGURATION =================

    STATIC_DEFENDER_DIR = Path("outputs/checkpoints")
    RL_ATTACKER_DIR = Path(OUTPUT_DIR) / "checkpoints"
    RESULTS_DIR = Path(OUTPUT_DIR) / "results"

    # =================================================

    if not CONFIG.seeds:
        raise ValueError("CONFIG.seeds must contain at least one seed.")

    if CONFIG.eval_episodes <= 0 or CONFIG.eval_horizon <= 0:
        raise ValueError("Evaluation episodes and horizon must be positive.")

    env = SecurityGame(CONFIG, seed=CONFIG.seeds[0])
    states = env.states
    actions = env.actions

    state_to_index = {state: i for i, state in enumerate(states)}
    action_to_index = {action: i for i, action in enumerate(actions)}

    expected_states = np.asarray(states, dtype=np.int8)
    expected_actions = np.asarray(actions, dtype=np.int16)

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    rows = []

    for seed_idx, training_seed in enumerate(CONFIG.seeds, start=1):

        static_defender_path = (
            STATIC_DEFENDER_DIR / f"q_seed_{training_seed}.npz"
        )

        rl_attacker_path = (
            RL_ATTACKER_DIR / f"multi_agent_q_seed_{training_seed}.npz"
        )

        Q_defender = load_and_validate_checkpoint(
            static_defender_path,
            expected_states,
            expected_actions,
            q_key="Q",
        )

        Q_attacker = load_and_validate_checkpoint(
            rl_attacker_path,
            expected_states,
            expected_actions,
            q_key="Q_attacker",
        )

        if Q_defender.shape != (len(states), len(actions)):
            raise ValueError(
                f"Unexpected defender Q shape: {Q_defender.shape}"
            )

        expected_attacker_shape = (len(states), len(actions), CONFIG.K)

        if Q_attacker.shape != expected_attacker_shape:
            raise ValueError(
                f"Unexpected attacker Q shape: {Q_attacker.shape}; "
                f"expected {expected_attacker_shape}"
            )

        # Frozen static-trained defender
        defender_policy = (
            lambda state, q=Q_defender: q_learning_policy(
                state,
                q,
                state_to_index,
                actions,
            )
        )

        # Frozen RL attacker
        attacker_policy = (
            lambda state, defense, q=Q_attacker: attacker_q_policy(
                state,
                defense,
                q,
                state_to_index,
                action_to_index,
            )
        )

        evaluation_seed = int(training_seed) + 200000

        print(
            f"[{seed_idx}/{len(CONFIG.seeds)}] "
            f"Defender seed {training_seed} vs "
            f"RL attacker seed {training_seed}..."
        )

        metrics = evaluate_policy(
            config=CONFIG,
            defender_policy=defender_policy,
            attacker_policy=attacker_policy,
            seed=evaluation_seed,
        )

        rows.append({
            "policy": "static_trained_defender_vs_rl_attacker",
            "defender_training_seed": int(training_seed),
            "attacker_training_seed": int(training_seed),
            "evaluation_seed": evaluation_seed,
            **metrics,
        })

    summary_input = [
        {
            "policy": row["policy"],
            "training_seed": row["defender_training_seed"],
            "evaluation_seed": row["evaluation_seed"],
            **{
                key: value
                for key, value in row.items()
                if key not in {
                    "policy",
                    "defender_training_seed",
                    "attacker_training_seed",
                    "evaluation_seed",
                }
            },
        }
        for row in rows
    ]

    summary = aggregate_results(summary_input)

    save_csv(
        RESULTS_DIR / "static_trained_defender_vs_rl_attacker_by_seed.csv",
        rows,
    )

    save_csv(
        RESULTS_DIR / "static_trained_defender_vs_rl_attacker_summary.csv",
        summary,
    )

    print("\nStatic-trained defender vs RL attacker")
    print("--------------------------------------")

    for row in summary:
        print(
            f"Defender return: {row['mean_discounted_return_mean']:.4f} "
            f"+/- {row['mean_discounted_return_std_across_seeds']:.4f}"
        )

        print(
            f"Attacker return: "
            f"{row['mean_discounted_attacker_return_mean']:.4f} "
            f"+/- {row['mean_discounted_attacker_return_std_across_seeds']:.4f}"
        )

        print(
            f"Infected loss: {row['mean_cumulative_loss_mean']:.4f} "
            f"+/- {row['mean_cumulative_loss_std_across_seeds']:.4f}"
        )

        print(
            f"Attack success: {row['attack_success_rate_mean']:.4f} "
            f"+/- {row['attack_success_rate_std_across_seeds']:.4f}"
        )

    print("\nPer-seed results:", RESULTS_DIR /
          "static_trained_defender_vs_rl_attacker_by_seed.csv")

    print("Summary:", RESULTS_DIR /
          "static_trained_defender_vs_rl_attacker_summary.csv")


if __name__ == "__main__":
    main()

if __name__ == "__main__":
    main()
