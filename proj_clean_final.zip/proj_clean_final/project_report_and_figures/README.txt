Adaptive Defense in a Repeated Attacker-Defender Security Game
Final Markdown report + figures

Contents:
- revised_mathematical_formulation_with_experiments_and_discussion.md
- report_figures/: 14 PNG plots referenced by the Markdown report, plus a figure manifest.

To preserve the embedded figures, unzip the archive and keep the report_figures folder beside the Markdown file. The report uses relative image paths such as report_figures/01_fai_policy_comparison.png.
