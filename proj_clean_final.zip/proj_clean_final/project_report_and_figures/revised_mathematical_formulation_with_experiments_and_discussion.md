# Adaptive Defense in a Repeated Attacker–Defender Security Game

**Final project report**  
*Mathematical formulation, methodology, experimental results, discussion, and contributions*

## Abstract

This project studies a repeated security game in which a defender allocates a limited protection budget across a collection of targets while an attacker selects one target to attack on each turn. We develop and evaluate two learning architectures. The first, FAI, trains a tabular Q-learning defender against a fixed deterministic greedy attacker and uses exact dynamic programming (DP) as an optimal benchmark for that fixed-opponent model. The second, FAI2, replaces the hand-coded attacker with an independent tabular Q-learning agent that observes the defender's allocation before choosing a target. This creates a sequential general-sum stochastic game with co-adapting policies. The report formalizes the state transitions, reward functions, action spaces, learning updates, and finite-horizon evaluation measures, then analyzes the experiments saved in the project archive. In the reference FAI experiments, Q-learning improves over the highest-value allocation but remains below the DP policy. In FAI2, the learned defender outperforms the fixed allocation against its paired learned attacker, while the two-agent learning curves and cross-play evaluations demonstrate that performance depends on the opponent and training dynamics. The experiments use four training seeds and a finite evaluation horizon; they do not establish convergence to an equilibrium.

**Keywords:** security games, attacker–defender interaction, Markov decision processes, tabular Q-learning, multi-agent reinforcement learning, dynamic programming.

## Project overview

The central design question is how a defender should distribute a finite protection budget when the attacker's behavior may be either prescribed or adaptive. The project addresses this in two stages: (i) a single-learning-agent setting with a deterministic myopic attacker (FAI), and (ii) a sequential two-agent setting in which both attacker and defender learn (FAI2). The first stage provides a controlled benchmark through exact value iteration; the second studies the added difficulty of mutual adaptation.

The report is organized as follows. Sections 1–3 define the game. Sections 4–6 describe the FAI and FAI2 algorithms and the heuristic baseline. Sections 7–8 define evaluation and discuss convergence qualifications. Sections 9–10 give the experimental methodology and results, Section 11 interprets the findings, and Sections 12–13 record contributions and summarize the conclusions. 

## 1. Model and notation

Consider a system containing $K$ targets, indexed by $i\in\{1,\ldots,K\}$. Target $i$ is characterized by:

- $V_i>0$: value of the target;
- $p_i\in[0,1]$: baseline probability that an attack on a healthy target succeeds in the absence of defense;
- $c_i>0$: cost paid by the attacker for attempting an attack on target $i$;
- $\rho_i\in[0,1]$: probability that an infected target recovers during one turn.

The defender has an integer defense budget $B\geq 0$. Let $\lambda\geq0$ denote the cost per unit of defense, $\eta\in(0,1)$ the effectiveness parameter of each allocated defense unit, and $\gamma\in(0,1)$ the discount factor.

### 1.1 State space

The infection state at time $t$ is

\[
 x_t=(x_{1,t},\ldots,x_{K,t})\in\mathcal X=\{0,1\}^K,
\]

where

\[
 x_{i,t}=\begin{cases}
 0,&\text{target }i\text{ is healthy},\\
 1,&\text{target }i\text{ is infected}.
 \end{cases}
\]

Thus, the state space contains $|\mathcal X|=2^K$ states. Unless otherwise specified, each training and evaluation rollout begins from the all-healthy state $x_0=(0,\ldots,0)$.

### 1.2 Defender action space

At each turn, the defender selects an integer allocation

\[
 d_t=(d_{1,t},\ldots,d_{K,t})\in\mathcal D_B,
\]

where

\[
 \boxed{\mathcal D_B=
 \left\{d\in\mathbb Z_{\geq0}^{K}:\sum_{i=1}^{K}d_i\leq B\right\}.}
\]

The constraint is an upper bound: the defender may leave part of its budget unused. The number of legal allocations is

\[
 |\mathcal D_B|=\binom{K+B}{B}.
\]

For example, when $K=5$ and $B=2$, there are $\binom{7}{2}=21$ legal defender actions.

### 1.3 Attack success probability

If the defender allocates $d_i$ units to target $i$, its probability of being successfully infected by an attack is reduced to

\[
 \boxed{q_i(d_i)=p_i(1-\eta)^{d_i}.}
\]

Each additional unit of defense therefore multiplies the baseline attack-success probability by $(1-\eta)$. The probability depends only on the allocation to the selected target, not on the allocations to other targets.

## 2. Turn order and state-transition dynamics

Each turn follows the same sequence:

1. Both agents observe the current infection state $x_t$.
2. The defender selects an allocation $d_t\in\mathcal D_B$.
3. The attacker observes both $x_t$ and $d_t$, and selects one target $a_t\in\{1,\ldots,K\}$.
4. An attack outcome is sampled. If the selected target was healthy and the attack succeeds, it becomes infected.
5. Targets that were already infected at the beginning of the turn independently undergo recovery.
6. The resulting state is $x_{t+1}$.

The recovery rule is applied to targets infected at the **beginning** of the turn. A target newly infected during the current attack is not eligible to recover in that same turn.

### 2.1 Conditional transition probabilities

For a fixed state $x$, defense allocation $d$, and attacked target $a$, define

\[
 \Pr(x'_{i}=1\mid x,d,a)=
 \begin{cases}
 1-\rho_i,&x_i=1,\\
 q_i(d_i),&x_i=0\text{ and }i=a,\\
 0,&x_i=0\text{ and }i\ne a.
 \end{cases}
\]

The probability of a healthy next state for target $i$ is the complement:

\[
 \Pr(x'_i=0\mid x,d,a)=1-\Pr(x'_i=1\mid x,d,a).
\]

Equivalently, the transition kernel factorizes over targets as

\[
 \boxed{P(x'\mid x,d,a)=\prod_{i=1}^{K}P_i(x'_i\mid x,d,a).}
\]

The factorization follows from the implementation's independent attack-outcome and per-target recovery draws, conditional on the current state and selected actions. Only one target is attacked per turn.

The expected number of newly infected targets in one turn is therefore either zero or the success probability of the single selected target, depending on whether that target is healthy. In particular, selecting an already infected target cannot create another infection; the attacker still pays the cost of the attempt.

## 3. Rewards and objectives

### 3.1 Defender reward

The weighted loss caused by currently infected targets is

\[
 L(x)=\sum_{i=1}^{K}V_i x_i.
\]

The text in the original review described this quantity as the value of *healthy* targets. That description is incorrect: because $x_i=1$ denotes infection, the expression sums the values of infected targets.

The defense expenditure at a turn is

\[
 C_D(d)=\lambda\sum_{i=1}^{K}d_i.
\]

The implemented defender reward is

\[
 \boxed{r_D(x,d)=-L(x)-C_D(d)
 =-\sum_{i=1}^{K}V_ix_i-\lambda\sum_{i=1}^{K}d_i.}
\]

The reward is calculated from the state at the **beginning** of the turn and the defense allocation selected for that turn. Infection and recovery outcomes determine the next state and affect subsequent rewards.

The defender seeks to maximize its expected discounted return:

\[
 J_D(\pi_D,\pi_A;x_0)
 =\mathbb E^{\pi_D,\pi_A}_{x_0}
 \left[\sum_{t=0}^{\infty}\gamma^t r_D(x_t,d_t)\right].
\]

Here $\pi_D$ is the defender policy and $\pi_A$ is the attacker's policy, with the latter allowed to depend on the current defense allocation.

### 3.2 Attacker reward and one-step utility

The multi-agent implementation assigns the attacker the realized reward

\[
 \boxed{r_A(x,a,x')
 =V_a\,\mathbf 1\{x_a=0,\ x'_a=1\}-c_a.}
\]

Thus, the attacker receives the target value only when its attempt creates a new infection, and it pays the attack cost on every attempt, including unsuccessful attempts and attempts directed at already infected targets.

Conditioned on the current state, defense allocation, and selected target, the expected attacker reward is

\[
 \begin{aligned}
 \bar r_A(x,d,a)
 &=\mathbb E[r_A\mid x,d,a]\\
 &=V_a(1-x_a)q_a(d_a)-c_a.
 \end{aligned}
\]

Define the attacker's immediate expected utility by

\[
 \boxed{U_A(x,d,a)=V_a(1-x_a)q_a(d_a)-c_a.}
\]

This is the same one-step expected utility used by the deterministic attacker in FAI. In FAI2, the attacker instead receives the stochastic reward $r_A$ and learns a policy for maximizing its own long-term discounted return,

\[
 J_A(\pi_D,\pi_A;x_0)
 =\mathbb E^{\pi_D,\pi_A}_{x_0}
 \left[\sum_{t=0}^{\infty}\gamma^t r_A(x_t,a_t,x_{t+1})\right].
\]

The two agents' rewards are **not negatives of one another**. The defender pays for defense and loses value from all currently infected targets, while the attacker receives value for a newly infected target and pays an attack cost. The two-agent formulation is consequently a general-sum game, not a zero-sum game.

## 4. FAI: defender learning against a deterministic greedy attacker

In the original FAI implementation, the attacker does not learn. After observing the defender's allocation, it chooses a target maximizing its immediate expected utility:

\[
 \boxed{a^*(x,d)\in\arg\max_{a\in\{1,\ldots,K\}}U_A(x,d,a).}
\]

Ties are resolved deterministically in favor of the smallest target index. This is a **myopic best response**: it maximizes the current expected attack reward and does not optimize a separate long-term attacker value function.

Because this response rule is fixed, it induces a stationary transition kernel for the defender:

\[
 P^*(x'\mid x,d)=P(x'\mid x,d,a^*(x,d)).
\]

The defender's problem is therefore a finite discounted Markov decision process

\[
 \mathcal M_D=(\mathcal X,\mathcal D_B,P^*,r_D,\gamma).
\]

### 4.1 Dynamic-programming solution

For the FAI model, the optimal value function satisfies

\[
 \boxed{V^*(x)=\max_{d\in\mathcal D_B}
 \left[r_D(x,d)+\gamma\sum_{x'\in\mathcal X}
 P^*(x'\mid x,d)V^*(x')\right].}
\]

The corresponding action-value function is

\[
 Q^*(x,d)=r_D(x,d)+\gamma\sum_{x'\in\mathcal X}
 P^*(x'\mid x,d)V^*(x'),
\]

and an optimal deterministic defender policy is

\[
 \pi_D^*(x)\in\arg\max_{d\in\mathcal D_B}Q^*(x,d).
\]

The implementation computes this solution by value iteration over the enumerated states and defense actions, using the exact transition distribution. This dynamic-programming benchmark applies to the fixed greedy-attacker model; it is not an equilibrium solution of the later two-agent learning game.

### 4.2 Tabular Q-learning for the defender

The FAI defender maintains

\[
 Q_D:\mathcal X\times\mathcal D_B\to\mathbb R.
\]

At each time step, it selects a uniformly random legal defense allocation with probability $\epsilon_t^D$ and otherwise selects a greedy action:

\[
 d_t=\begin{cases}
 \text{uniformly sampled from }\mathcal D_B,&\text{with probability }\epsilon_t^D,\\
 \arg\max_{d\in\mathcal D_B}Q_D(x_t,d),&\text{otherwise}.
 \end{cases}
\]

The exploration rate is linearly decayed and bounded below:

\[
 \boxed{\epsilon_t^D=\epsilon_{\min}^D+
 (\epsilon_0^D-\epsilon_{\min}^D)
 \max\left(1-\frac{t}{T_D},0\right),}
\]

where $T_D$ is the configured decay duration in environment steps. The update uses a constant learning rate $\alpha_D$:

\[
 \boxed{
 Q_D(x_t,d_t)\leftarrow Q_D(x_t,d_t)+\alpha_D
 \left[r_D(x_t,d_t)+\gamma\max_{d'\in\mathcal D_B}
 Q_D(x_{t+1},d')-Q_D(x_t,d_t)\right].}
\]

The resulting frozen defender policy is greedy with respect to the learned table:

\[
 \pi_D^{\mathrm{RL}}(x)\in\arg\max_{d\in\mathcal D_B}Q_D(x,d).
\]

## 5. FAI2: sequential two-agent Q-learning

FAI2 replaces the hand-coded attacker response with a second learning agent. The move order remains sequential within each turn: the defender selects $d_t$ first, and the attacker observes that allocation before selecting $a_t$.

The process is described by

\[
 x_t\xrightarrow{\pi_D}d_t
 \xrightarrow{\pi_A(\cdot\mid x_t,d_t)}a_t
 \xrightarrow{P(\cdot\mid x_t,d_t,a_t)}x_{t+1}.
\]

Both agents seek to maximize their own discounted returns, $J_D$ and $J_A$. Since the rewards are not opposites, this is a general-sum sequential-move stochastic game. The agents are trained as independent tabular Q-learners; no Nash-equilibrium or Stackelberg-equilibrium computation is performed.

### 5.1 Defender action-value function

The defender's observation and action remain the infection state and defense allocation, respectively:

\[
 Q_D:\mathcal X\times\mathcal D_B\to\mathbb R.
\]

Its action is selected using its own epsilon-greedy policy. The implemented update is

\[
 \boxed{
 Q_D(x_t,d_t)\leftarrow Q_D(x_t,d_t)+\alpha_D
 \left[r_D(x_t,d_t)+\gamma\max_{d'\in\mathcal D_B}
 Q_D(x_{t+1},d')-Q_D(x_t,d_t)\right].}
\]

The opponent's action is not an explicit index in the defender's table. Its effect enters through the realized state transition and the defender reward sequence. During joint training, however, the attacker's policy is changing, so the transition distribution experienced by the defender is not stationary.

### 5.2 Attacker action-value function

The attacker observes both the infection state and the defense allocation before selecting a target. Its Q-table is therefore indexed by all three quantities:

\[
 \boxed{Q_A:\mathcal X\times\mathcal D_B\times
 \{1,\ldots,K\}\to\mathbb R.}
\]

The attacker selects a uniformly random target with probability $\epsilon_t^A$ and otherwise chooses

\[
 a_t\in\arg\max_{a\in\{1,\ldots,K\}}Q_A(x_t,d_t,a).
\]

Its exploration schedule is independently linearly decayed:

\[
 \boxed{\epsilon_t^A=\epsilon_{\min}^A+
 (\epsilon_0^A-\epsilon_{\min}^A)
 \max\left(1-\frac{t}{T_A},0\right).}
\]

The attacker update uses the realized reward $r_A(x_t,a_t,x_{t+1})$. At the next time step, the defender acts first. The implementation therefore bootstraps the attacker over the defender's next epsilon-greedy action distribution, and then takes the greedy attack value for each possible next defense.

Let

\[
 d_g(x')\in\arg\max_{d'\in\mathcal D_B}Q_D(x',d')
\]

be the next greedy defense allocation. The expected next attacker value used by the implementation is

\[
 \boxed{
 \begin{aligned}
 \bar V_A(x')={}&(1-\epsilon_{t+1}^D)
 \max_a Q_A(x',d_g(x'),a)\\
 &+\frac{\epsilon_{t+1}^D}{|\mathcal D_B|}
 \sum_{d'\in\mathcal D_B}\max_a Q_A(x',d',a).
 \end{aligned}}
 \]

The attacker Q-update is then

\[
 \boxed{
 \begin{aligned}
 Q_A(x_t,d_t,a_t)\leftarrow{}&Q_A(x_t,d_t,a_t)+\alpha_A\big[ r_A(x_t,a_t,x_{t+1})\\
 &+\gamma\bar V_A(x_{t+1})-Q_A(x_t,d_t,a_t)\big].
 \end{aligned}}
 \]

This bootstrap reflects the implemented move order: the attacker does not choose the next defense. The next defense is sampled from the defender's epsilon-greedy policy; after observing it, the attacker uses its greedy continuation value in the Q-learning target. The attacker's own next-step exploration probability is not inserted into this off-policy maximum target.

### 5.3 Frozen policies

After training, the policies used for evaluation are greedy and do not continue exploring:

\[
 \pi_D^{\mathrm{RL}}(x)\in\arg\max_{d\in\mathcal D_B}Q_D(x,d),
 \qquad
 \pi_A^{\mathrm{RL}}(x,d)\in\arg\max_{a}Q_A(x,d,a).
\]

This separates learning-time behavior, which includes exploration by both agents, from frozen-policy evaluation, which uses the learned greedy decisions.

## 6. Heuristic baseline retained

Only the highest-value heuristic is retained as a non-learning baseline. It allocates one unit to each of the $B$ targets with the largest values $V_i$ when $B\leq K$:

\[
 d_i^{\mathrm{HV}}=
 \begin{cases}
 1,&i\text{ is among the }B\text{ highest-value targets},\\
 0,&\text{otherwise}.
 \end{cases}
\]

Ties in target value are broken by target index. In the tested configurations, $K=5$ and $B\in\{2,3,5\}$ for FAI, while FAI2 uses $K=5,B=2$. The implemented uniform allocation produces exactly the same allocation vectors as the highest-value heuristic in these configurations because the target values are already ordered from largest to smallest. It is therefore redundant as a separate baseline and is omitted from the revised report.

## 7. Evaluation quantities and finite-horizon protocol

The theoretical discounted objectives above are infinite-horizon objectives. The experiments, however, evaluate frozen policies using rollouts of a configured finite horizon $H$. For one evaluation rollout, the defender's discounted return is

\[
 G_D^{(e)}=\sum_{t=0}^{H-1}\gamma^t r_D(x_t^{(e)},d_t^{(e)}),
\]

and in FAI2 the attacker's discounted return is

\[
 G_A^{(e)}=\sum_{t=0}^{H-1}\gamma^t r_A(x_t^{(e)},a_t^{(e)},x_{t+1}^{(e)}).
\]

With $N$ evaluation rollouts, the reported mean discounted return is the sample average

\[
 \widehat J_D^{(H)}=\frac{1}{N}\sum_{e=1}^{N}G_D^{(e)},
 \qquad
 \widehat J_A^{(H)}=\frac{1}{N}\sum_{e=1}^{N}G_A^{(e)}.
\]

The following additional quantities are accumulated without discounting within each rollout:

**Cumulative infected-target loss**

\[
 L_{\mathrm{cum}}^{(e)}=
 \sum_{t=0}^{H-1}\sum_{i=1}^{K}V_i x_{i,t}^{(e)}.
\]

**Cumulative defense cost**

\[
 C_{\mathrm{def}}^{(e)}=
 \lambda\sum_{t=0}^{H-1}\sum_{i=1}^{K}d_{i,t}^{(e)}.
\]

**Attack success rate**

\[
 \mathrm{ASR}=
 \frac{\text{successful attacks that create new infections}}
 {\text{attacks directed at targets healthy at the beginning of the turn}}.
\]

Attempts against already infected targets are excluded from the denominator of this rate. The implementation also records new infections and recoveries per rollout, and attack frequencies by target.

### 7.1 Empirical performance loss in FAI

The FAI implementation solves the infinite-horizon MDP by value iteration, but its reported policy-performance-loss metric is calculated from finite-horizon simulated returns. For each training seed, all policies use the same evaluation seed. Let $\widehat J_{\mathrm{DP},e}^{(H)}$ be the mean finite-horizon evaluation return of the dynamic-programming policy for that seed, and let $\widehat J_{\pi,e}^{(H)}$ be the corresponding return of another policy. The implemented empirical performance loss is

\[
 \boxed{\mathrm{PoL}_e(\pi)=
 \frac{\widehat J_{\mathrm{DP},e}^{(H)}-
 \widehat J_{\pi,e}^{(H)}}
 {|\widehat J_{\mathrm{DP},e}^{(H)}|}.}
\]

The dynamic-programming policy has performance loss zero by definition. This empirical finite-horizon quantity should not be confused with the gap between an exact infinite-horizon value and a finite-horizon Monte Carlo return. The FAI2 experiments do not use this DP performance-loss metric: the optional best-response dynamic-programming benchmark against a frozen learned attacker is disabled in the saved configurations.

## 8. Interpretation and convergence qualifications

In FAI, fixing the deterministic attacker response makes the defender's environment a stationary finite discounted MDP. The exact value-iteration solution is therefore well-defined for the configured model. The Q-learning implementation nevertheless uses a constant learning rate rather than a diminishing per-state-action step size. Consequently, the classical tabular Q-learning convergence theorem does not directly certify convergence of the finite experimental runs.

In FAI2, both policies change during training. From either learner's perspective, the other learner changes the effective transition or reward distribution over time. The joint process is therefore non-stationary during learning. The implemented independent Q-learning procedure is an empirical learning method for this general-sum game; it does not come with a guarantee of convergence to a Nash equilibrium, a Stackelberg equilibrium, or a stationary joint policy.

Training and evaluation should accordingly be distinguished. Training returns are collected while exploration is active and, in FAI2, while both agents are adapting. Frozen-policy evaluation disables exploration and measures the behavior of the learned greedy policies over finite rollouts. A training curve is evidence about learning dynamics; it is not itself a substitute for frozen-policy evaluation.

## 9. Methodology

### 9.1 Common experimental testbed

The principal experiments use a five-target system with an initial all-healthy state. The reference configuration is

\[
K=5,\quad B=2,\quad \eta=0.20,\quad \lambda=0.75,\quad \gamma=0.95.
\]

The target-specific parameters are

\[
\begin{aligned}
(V_1,\ldots,V_5)&=(10,8,6,4,3),\\
(p_1,\ldots,p_5)&=(0.60,0.55,0.45,0.35,0.30),\\
(c_1,\ldots,c_5)&=(1,1,1,1,1),\\
(\rho_1,\ldots,\rho_5)&=(0.20,0.15,0.25,0.30,0.20).
\end{aligned}
\]

Thus, the state space contains 32 infection states. With a budget of two units, the defender has 21 legal allocations, giving 672 state--defense pairs in the defender's Q-table. In FAI2, the attacker observes the state and the chosen defense allocation, so its Q-table has \(32\times21\times5=3360\) state--defense--target entries. The FAI budget experiments also use \(B=3\) and \(B=5\), for which the defender has 56 and 252 legal allocations, respectively.

Unless otherwise stated, the saved configurations set `initial_state` to `null`, which resets every training and evaluation episode to the all-healthy state. The four training seeds used in the experiment outputs are \(42,169,6969,696969\). These are the seeds recorded in the saved run configurations; they differ from the five-seed defaults in the source `config.py` files.

### 9.2 Algorithmic methodology and implementation

The implementation follows the two architectures formalized in Sections 4 and 5. Both use a finite tabular state representation: an infection vector with 32 possible states for the five-target experiments. The defender's action is an integer allocation satisfying the total budget constraint. The implementation enumerates all legal allocations, so the tabular agents compare complete legal actions rather than selecting defense units independently.

**FAI: model-based benchmark and single-agent learning.** The FAI procedure has a fixed deterministic attacker and a learning defender:

1. Enumerate the infection states and all legal defender allocations. For every state–allocation pair, calculate the attacker's myopic response by maximizing the immediate expected utility in Section 3.2. The smallest target index resolves ties.
2. Construct the induced transition kernel using the attack outcome and independent recovery probabilities. Apply value iteration to this finite discounted MDP to obtain the DP reference policy.
3. Initialize the defender's Q-table. At the start of each training episode, reset the system to the all-healthy state unless an alternate initial state is explicitly configured.
4. At each turn, choose a legal allocation using the defender's epsilon-greedy policy. The deterministic attacker observes the allocation and selects its greedy target. Sample the transition and calculate the defender reward.
5. Update the selected state–allocation entry with the one-step Q-learning update in Section 4.2. Linearly decay exploration, subject to the configured minimum.
6. Freeze the learned Q-table and evaluate its greedy policy against the same deterministic attacker. Compare it with the exact DP policy and the fixed highest-value allocation.

The DP policy is an exact reference for the finite MDP induced by the specified greedy attacker. It is not an equilibrium benchmark for FAI2.

**FAI2: sequential independent Q-learning.** FAI2 retains the same state transition and defender allocation space but adds an attacker Q-table. The agents move in sequence:

1. The defender observes the current infection state and selects an allocation using its epsilon-greedy policy over the defender Q-table.
2. The attacker observes both the infection state and the selected allocation, then chooses a target using its own epsilon-greedy policy over the attacker Q-table.
3. Sample whether a healthy target becomes infected and independently sample recovery for targets that were infected at the beginning of the turn. Calculate the defender and attacker rewards using their distinct reward functions.
4. Update the defender Q-table using its observed reward and next infection state. Update the attacker Q-table using the realized attack reward and the continuation value that averages over the defender's next epsilon-greedy allocation distribution before maximizing over the next attack target, as formalized in Section 5.2.
5. Decay the two exploration schedules independently and continue joint training. Both Q-tables are frozen after training, and greedy policies are evaluated with exploration disabled.

The FAI2 agents are trained independently; the implementation does not solve a Nash or Stackelberg equilibrium. Because each learner's policy changes the other learner's experience, the effective environment is non-stationary during joint training. This is a substantive architectural difference from FAI, not merely the addition of a second Q-table.

**Architecture summary.**

| Component | FAI | FAI2 |
|---|---|---|
| Learning agents | Defender only | Defender and attacker |
| Attacker decision | Deterministic myopic best response | Learned epsilon-greedy policy conditioned on state and defense |
| Defender Q-table | \(Q_D(x,d)\) | \(Q_D(x,d)\) |
| Attacker Q-table | None | \(Q_A(x,d,a)\) |
| Reference solution | Exact DP for the fixed-attacker MDP | No equilibrium solution computed |
| Training environment | Stationary transition kernel for the defender | Non-stationary from each learner's perspective during joint learning |

The complete update equations and the precise transition/reward definitions are given in Sections 1–5; this subsection records the execution sequence followed by the archived implementations.

### 9.3 Training protocols

**FAI: defender learning against the deterministic greedy attacker.** The defender is trained for 500, 10,000, or 50,000 episodes, with 100 environment steps per episode. The reference learning rate is \(\alpha_D=0.10\), and the exploration probability is linearly decayed from 1.0 to 0.05. The reference 10,000-episode run uses 200,000 environment steps for the decay; the 50,000-episode run uses 1,000,000 steps. The saved 500-episode run uses \(\eta=0.10\) and a 10,000-step decay, whereas the 10,000- and 50,000-episode reference runs use \(\eta=0.20\). Consequently, the 500-episode result is not a strictly matched shorter-training version of the latter two runs.

For FAI, the exact value-iteration solution is computed for each configuration using tolerance \(10^{-8}\) and a maximum of 10,000 iterations. Each learned Q-table is evaluated greedily, alongside the dynamic-programming, highest-value, and uniform policies. The saved FAI configurations use 1,000 evaluation episodes of 100 steps each.

**FAI2: joint learning by the defender and attacker.** Both agents are trained for 500, 10,000, or 50,000 episodes, again with 100 environment steps per episode. The reference learning rates are \(\alpha_D=\alpha_A=0.10\). Both exploration probabilities start at 1.0 and decay to 0.05. The reference decay durations are 10,000, 200,000, and 1,000,000 environment steps for the 500-, 10,000-, and 50,000-episode runs, respectively. The saved FAI2 configurations set `run_best_response_dp` to `false`; no dynamic-programming best-response benchmark is included in these reported two-agent runs.

The principal FAI2 baseline configurations use 10,000 evaluation episodes of 100 steps each. Some sensitivity runs use 1,000 evaluation episodes, while others retain 10,000; the evaluation count for each run is recorded in its `config.json`. After training, both agents are evaluated greedily, with exploration disabled. Each defender policy in a given seed's comparison is paired with that seed's frozen learned attacker.

### 9.4 Parameter studies

The FAI experiments vary the defender's action-space size and selected environment and learning parameters. At 10,000 episodes, the budget is tested at \(B\in\{2,3,5\}\); the attack-defense effectiveness is tested at \(\eta\in\{0.05,0.20,0.40\}\); and the learning rate is tested at \(\alpha_D\in\{0.05,0.10,0.20,0.40\}\). The 10,000-episode exploration study includes a shorter 20,000-step decay instead of the 200,000-step reference decay. At 50,000 episodes, additional runs test \(\eta=0.05\) and \(0.40\), and defense-cost coefficients \(\lambda=0.25\) and \(1.50\), against the reference \(\lambda=0.75\). One 10,000-episode run saved under the `lda=0.25` directory changes both \(\eta\) and \(\lambda\) (to 0.10 and 0.25); it is therefore not an isolated test of \(\lambda\).

The FAI2 sensitivity experiments vary one learner's parameters while retaining the reference settings for the other learner. The defender and attacker learning rates are separately tested at 0.05, 0.20, and 0.40 around the reference value 0.10. Each agent's exploration-decay duration is also varied to 0.1, 2, and 4 times the reference duration for the corresponding training length. These runs form a set of one-factor sensitivity checks, not a complete factorial search over all combinations. The archive also contains exploratory 500-episode FAI2 tuning variants; most of those variants use 1,000 evaluation episodes, whereas the 500-episode reference configuration uses 10,000. They are therefore retained as supplementary outputs rather than mixed into the primary sensitivity tables, which focus on the more directly comparable 10,000- and 50,000-episode sweeps.

Two additional FAI2 cross-play evaluations test whether performance transfers between opponent types. In one direction, a defender trained in FAI against the deterministic greedy attacker is evaluated against a frozen FAI2 learned attacker. In the other direction, a defender trained jointly in FAI2 is evaluated against the deterministic greedy attacker. These auxiliary cross-play CSVs contain four seed-level records per training duration, but do not include their own `config.json`; their exact evaluation episode count and horizon therefore cannot be verified from the archived files.

### 9.5 Evaluation and aggregation

The primary reported return for each evaluation rollout is the finite-horizon discounted return defined in Section 7. In addition, cumulative infected-target loss, cumulative defense cost, attack success rate, new infections, recoveries, and attack frequencies are recorded. FAI2 also records the attacker's discounted return and cumulative attack cost. The FAI performance-loss statistic is calculated relative to the dynamic-programming policy's finite-horizon simulated return, as specified in Section 7.1.

For each training seed, evaluation produces a seed-level average over the configured rollouts. Tables below report the mean and sample standard deviation of these seed-level averages across the four training seeds. Thus, the displayed standard deviations measure variation between training seeds, not the standard deviation of individual time steps. Learning curves are plotted from the mean training history across seeds using a 20-episode moving average.

## 10. Results

### 10.1 FAI: fixed-attacker benchmark and learning results

Table 1 reports the principal FAI reference runs. The dynamic-programming and heuristic columns are included as evaluation references; the Q-learning column is the learned defender. All returns in this table are finite-horizon evaluation means over 1,000 rollouts of 100 steps, aggregated across four training seeds.

| Training episodes | \(\eta\) | DP return | Q-learning return | Highest-value / uniform return | Q-learning PoL |
|---:|---:|---:|---:|---:|---:|
| 500 | 0.10 | \(-287.31\pm0.55\) | \(-315.72\pm3.43\) | \(-314.93\pm2.31\) | \(0.099\pm0.012\) |
| 10,000 | 0.20 | \(-262.81\pm1.36\) | \(-294.89\pm7.66\) | \(-299.83\pm1.18\) | \(0.122\pm0.026\) |
| 50,000 | 0.20 | \(-262.81\pm1.36\) | \(-288.96\pm11.06\) | \(-299.83\pm1.18\) | \(0.099\pm0.040\) |

For the reference \(\eta=0.20\) configuration, the exact infinite-horizon dynamic-programming value at the all-healthy initial state is \(V^*(x_0)=-265.1873\). This is distinct from the DP policy's finite-horizon Monte Carlo mean of approximately \(-262.81\) in Table 1: the latter omits rewards after the 100-step evaluation horizon. Between the 10,000- and 50,000-episode FAI runs, the Q-learning mean return improves by approximately 5.93, and its empirical performance loss falls from 0.122 to 0.099. The learned policy nevertheless remains below the dynamic-programming policy in these evaluations.

![FAI policy comparison across reference training lengths](report_figures/01_fai_policy_comparison.png)

*Figure 1. Mean finite-horizon defender return for the DP, Q-learning, and highest-value policies. Error bars show standard deviation across the four training seeds. The 500-episode run uses \(\eta=0.10\), while the longer reference runs use \(\eta=0.20\); therefore, the three points are not a controlled episode-count-only comparison.*

![FAI training curve for the 50,000-episode reference run](report_figures/02_fai_learning_curve_50000.png)

*Figure 2. Archived training curve for the 50,000-episode FAI reference run. The learning trajectory is noisy and should be interpreted as training behavior, not as proof of convergence.*

### 10.2 FAI: parameter sensitivity

The parameter sweeps examine whether the finite-budget tabular learner is sensitive to the size of its legal action set, the attack-defense interaction, and the learning schedule. Table 2 reports the mean empirical performance loss and its across-seed standard deviation. Lower values indicate a smaller normalized gap to the DP policy within that configuration.

| Sweep | Setting | Mean empirical performance loss \(\pm\) SD |
|---|---:|---:|
| Budget, 10k episodes | \(B=2\) | \(0.122\pm0.026\) |
|  | \(B=3\) | \(0.134\pm0.094\) |
|  | \(B=5\) | \(0.295\pm0.044\) |
| Effectiveness, 10k episodes | \(\eta=0.05\) | \(0.054\pm0.015\) |
|  | \(\eta=0.20\) | \(0.122\pm0.026\) |
|  | \(\eta=0.40\) | \(0.162\pm0.036\) |
| Effectiveness, 50k episodes | \(\eta=0.05\) | \(0.045\pm0.024\) |
|  | \(\eta=0.20\) | \(0.099\pm0.040\) |
|  | \(\eta=0.40\) | \(0.176\pm0.105\) |
| Defender learning rate, 10k episodes | \(\alpha_D=0.05\) | \(0.100\pm0.046\) |
|  | \(\alpha_D=0.10\) | \(0.122\pm0.026\) |
|  | \(\alpha_D=0.20\) | \(0.153\pm0.044\) |
|  | \(\alpha_D=0.40\) | \(0.183\pm0.035\) |
| Exploration decay, 10k episodes | 200,000 steps (reference) | \(0.122\pm0.026\) |
|  | 20,000 steps | \(0.147\pm0.014\) |
| Defense cost, 50k episodes | \(\lambda=0.25\) | \(0.121\pm0.045\) |
|  | \(\lambda=0.75\) | \(0.099\pm0.040\) |
|  | \(\lambda=1.50\) | \(0.094\pm0.031\) |

![FAI budget sensitivity](report_figures/03_fai_budget_sensitivity.png)

*Figure 3. Empirical performance loss as the defender's action space grows from 21 to 56 to 252 legal allocations. The larger loss at \(B=5\) indicates a harder tabular learning problem under this fixed training budget; it does not imply that a larger defense budget has a lower optimal value.*

![FAI defense-effectiveness sensitivity](report_figures/04_fai_effectiveness_sensitivity.png)

*Figure 4. Normalized performance loss for the three effectiveness settings at both 10,000 and 50,000 training episodes. Because each value is normalized by its own DP reference, the plot compares relative optimality gaps rather than absolute defender returns across different environments. The 50,000-episode \(\eta=0.40\) run has substantial seed variation.*

![FAI learning-rate sensitivity](report_figures/05_fai_learning_rate_sensitivity.png)

*Figure 5. Effect of the defender's learning rate on empirical performance loss. In these runs, the lower learning rates perform better under the fixed 10,000-episode budget.*

![FAI exploration and defense-cost sensitivity](report_figures/06_fai_exploration_and_cost_sensitivity.png)

*Figure 6. The left panel compares the reference and shortened epsilon-decay schedules. The right panel compares defense-cost coefficients at 50,000 episodes. The cost-sweep losses are normalized against different DP references and should be read within each configuration.*

The FAI sensitivity evidence is descriptive and comes from four seeds per configuration. The budget sweep is especially variable at \(B=3\), and the cost coefficient changes the absolute reward scale as well as the reference policy. The plots therefore support comparisons within each sweep, not universal parameter recommendations.

### 10.3 FAI2: joint-learning results

Table 3 compares the jointly trained FAI2 defender against the highest-value baseline. Both defender policies are evaluated against the same seed's frozen learned attacker. The uniform baseline has the same allocation as the highest-value baseline in this testbed, so it produces identical results and is not listed separately.

| Training episodes | Learned defender return | Learned attacker's return | Highest-value defender return | Learned defender cumulative loss | Learned defender defense cost | Attack success rate |
|---:|---:|---:|---:|---:|---:|---:|
| 500 | \(-230.57\pm16.32\) | \(33.30\pm1.60\) | \(-260.67\pm25.67\) | \(1172.3\pm90.2\) | \(125.0\pm12.5\) | \(0.427\pm0.014\) |
| 10,000 | \(-271.48\pm11.04\) | \(42.03\pm1.76\) | \(-281.24\pm10.06\) | \(1421.8\pm23.5\) | \(103.9\pm14.0\) | \(0.459\pm0.015\) |
| 50,000 | \(-273.75\pm24.44\) | \(41.92\pm6.36\) | \(-287.11\pm7.54\) | \(1423.0\pm130.1\) | \(116.9\pm11.2\) | \(0.433\pm0.007\) |

In all three reference runs, the learned defender has a less negative mean return than the highest-value baseline under the paired learned attacker. The training curves for the 50,000-episode reference run show the two agents adapting on different reward scales: the attacker's moving-average return rises from the low twenties to the low-to-mid forties during the first approximately 10,000 episodes, while the defender's return becomes more negative over the same period and then fluctuates around its later-training level. The curves are consistent with the opponent adapting during joint training, but they are not evidence of convergence to an equilibrium. The 10,000- and 50,000-episode evaluation means are also similar, with substantial seed variation in the 50,000-episode learned-defender return.

![FAI2 learned defender versus highest-value baseline](report_figures/09_fai2_policy_returns.png)

*Figure 7. Frozen-policy defender returns when the learned defender and highest-value baseline face the same seed's frozen learned attacker. Higher (less negative) return is better.*

![FAI2 defender learning curve](report_figures/07_fai2_defender_learning_curve.png)

*Figure 8. Defender training return over 50,000 joint-training episodes.*

![FAI2 attacker learning curve](report_figures/08_fai2_attacker_learning_curve.png)

*Figure 9. Attacker training return over the same 50,000-episode run. The defender and attacker returns are on different reward scales and are not negatives of one another.*

![FAI2 cumulative loss and defense-cost comparison](report_figures/10_fai2_loss_and_defense_cost.png)

*Figure 10. Cumulative infection loss and defense expenditure for the learned defender and highest-value baseline in frozen-policy evaluation. These undiscounted diagnostics help explain the return differences.*

### 10.4 FAI2: learning-rate and exploration sensitivity

Table 4 reports the learned defender's mean discounted return \(\pm\) across-seed standard deviation for the one-factor learning-rate sweeps. In each sweep, only the indicated agent's learning rate changes; the other learner retains the reference setting. The 0.10 entries are the corresponding baseline runs.

| Varied agent | Learning rate | 10,000 episodes | 50,000 episodes |
|---|---:|---:|---:|
| Defender | 0.05 | \(-265.75\pm11.17\) | \(-268.88\pm14.91\) |
|  | 0.10 (reference) | \(-271.48\pm11.04\) | \(-273.75\pm24.44\) |
|  | 0.20 | \(-290.83\pm9.15\) | \(-294.57\pm5.68\) |
|  | 0.40 | \(-289.66\pm13.10\) | \(-290.29\pm9.12\) |
| Attacker | 0.05 | \(-274.11\pm6.85\) | \(-293.46\pm17.30\) |
|  | 0.10 (reference) | \(-271.48\pm11.04\) | \(-273.75\pm24.44\) |
|  | 0.20 | \(-262.38\pm15.79\) | \(-270.64\pm18.36\) |
|  | 0.40 | \(-264.10\pm8.56\) | \(-272.42\pm10.71\) |

Table 5 summarizes the exploration-decay duration sweeps. The multiplier is relative to the reference decay duration for that training length: 200,000 steps at 10,000 episodes and 1,000,000 steps at 50,000 episodes.

| Agent whose decay is varied | Decay multiplier | 10,000 episodes: defender return \(\pm\) SD | 50,000 episodes: defender return \(\pm\) SD |
|---|---:|---:|---:|
| Defender | 0.1\(\times\) | \(-278.75\pm4.93\) | \(-286.19\pm15.25\) |
|  | 2\(\times\) | \(-284.39\pm19.64\) | \(-283.49\pm14.68\) |
|  | 4\(\times\) | \(-277.77\pm11.98\) | \(-273.25\pm19.64\) |
| Attacker | 0.1\(\times\) | \(-289.08\pm14.01\) | \(-285.87\pm11.27\) |
|  | 2\(\times\) | \(-273.52\pm13.99\) | \(-279.26\pm14.59\) |
|  | 4\(\times\) | \(-275.23\pm22.29\) | \(-274.23\pm22.11\) |

![FAI2 learning-rate sensitivity](report_figures/11_fai2_learning_rate_sensitivity.png)

*Figure 11. Defender return under separate defender and attacker learning-rate sweeps. Error bars show across-seed standard deviations.*

![FAI2 exploration-decay sensitivity](report_figures/12_fai2_exploration_decay_sensitivity.png)

*Figure 12. Defender return under separate exploration-decay sweeps for the defender and attacker. No monotonic rule holds across both training lengths and both agents.*

The sensitivity results are non-monotonic, particularly for the attacker's update rate and for exploration decay. This is expected to be harder to interpret than a single-agent sweep: altering one agent's update schedule also changes the transition/reward data encountered by the other. Four seeds are insufficient to select a universally best hyperparameter pair, so these results should be read as evidence of sensitivity rather than as a definitive tuning prescription. The evaluation sample size is not identical across all sensitivity folders: the baseline runs use 10,000 evaluation rollouts, while most one-factor variants use 1,000 (with a few decay variants retaining 10,000). The displayed standard deviations are across training-seed means and therefore include differing amounts of Monte Carlo evaluation noise. The hyperparameter comparisons are descriptive, not controlled significance tests.

### 10.5 Cross-play and opponent transfer

The auxiliary cross-play evaluations are summarized in Table 6. “FAI-trained defender” denotes the Q-learning defender trained against the deterministic greedy attacker in FAI. “FAI2-trained defender” denotes the defender trained jointly with the FAI2 attacker. Returns are shown as defender / attacker means, with standard deviations across the four seed-level records.

| Training episodes | FAI2-trained defender vs. greedy attacker | FAI-trained defender vs. FAI2 learned attacker |
|---:|---:|---:|
| 500 | \(-305.12\pm12.33\; / \;49.40\pm3.20\) | \(-284.03\pm8.63\; / \;43.24\pm1.94\) |
| 10,000 | \(-290.12\pm10.36\; / \;46.26\pm4.39\) | \(-283.73\pm6.24\; / \;43.64\pm1.59\) |
| 50,000 | \(-292.57\pm4.95\; / \;46.25\pm0.88\) | \(-288.43\pm11.19\; / \;45.82\pm2.90\) |

These tests indicate that the performance of a learned defender depends on the opponent against which it is evaluated. They should not be read as a direct ranking of FAI and FAI2, because the two columns involve different defender training environments and different frozen evaluation opponents. They also do not constitute equilibrium tests.

![Cross-play defender returns](report_figures/13_crossplay_defender_returns.png)

*Figure 13. Defender returns in the two cross-play directions. The opponent used at evaluation differs from the opponent used during defender training.*

### 10.6 Attack-target selection patterns

The FAI2 evaluation archive also records the fraction of attacks directed at each target. Figure 14 shows these frequencies for the 10,000-episode baseline policies. These frequencies provide a descriptive view of the attacker’s selected targets under the two defender policies. They should not be interpreted as an intrinsic target ranking: the attacker's observed allocation differs by defender policy, and the displayed frequencies aggregate the resulting paired evaluation trajectories.

![FAI2 attack frequencies by target](report_figures/14_fai2_attack_target_frequencies.png)

*Figure 14. Empirical attack-frequency distribution across the five targets in FAI2 baseline evaluation.*

### 10.7 Data-integrity notes and limitations

The per-seed `results_by_seed.csv` files were used as the aggregation source for the reported means and standard deviations. This is important because the saved FAI summary files for the 50,000-episode \(\eta=0.05\) and \(\eta=0.40\) runs are byte-identical even though their per-seed result files differ. The values for those sensitivity runs were therefore aggregated from their distinct per-seed records rather than copied from the duplicated summary files. Two experiment folders lack a `summary.csv` despite containing per-seed records; those records were sufficient for aggregation. In the FAI2 auxiliary cross-play results, the 10,000-episode FAI2-defender-versus-greedy-attacker per-seed file is duplicated byte-for-byte in two experiment folders and is treated as one result set, not as two independent experiments.

All principal comparisons use four training seeds. FAI2's joint learning process is non-stationary from each agent's perspective, and the experiments do not compute a Nash or Stackelberg equilibrium. The finite training horizons, constant learning rates, finite evaluation horizon, and small number of seeds therefore limit any convergence or generalization claims. The results support empirical comparisons of the saved configurations, not a theoretical guarantee that either learner converges to an optimal or equilibrium policy.

## 11. Discussion

### 11.1 What the fixed-opponent experiments establish

FAI provides the controlled setting in which to assess defender learning independently of opponent adaptation. The deterministic attacker selects the target with the largest immediate expected attack utility, so fixing this response induces a stationary transition model for the defender. This makes the value-iteration solution a meaningful optimal reference for the FAI formulation, rather than merely another learned policy.

The tabular defender improves as training is extended from 10,000 to 50,000 episodes: its mean finite-horizon return changes from \(-294.89\) to \(-288.96\), and its empirical performance loss relative to the dynamic-programming policy falls from 0.122 to 0.099. The learned policy also outperforms the highest-value allocation, whose return is \(-299.83\), at both training durations. These gains indicate that the Q-table is learning useful state-dependent allocations. However, the remaining gap to the dynamic-programming return of \(-262.81\) shows that the tested training budget and tabular update procedure do not recover the optimal FAI policy. The model-based solver can evaluate every legal allocation using the exact transition distribution, whereas Q-learning must estimate action values from sampled trajectories. The results therefore illustrate the practical difference between exact planning with a known model and model-free value estimation.

The budget experiment makes the tabular limitation more apparent. At \(K=5\), increasing \(B\) from 2 to 3 and 5 increases the number of legal allocations from 21 to 56 and 252. The corresponding defender Q-table grows from 672 to 1,792 and 8,064 state--action entries. With the training duration held at 10,000 episodes, the reported performance loss rises from 0.122 at \(B=2\), to 0.134 at \(B=3\), and 0.295 at \(B=5\). This pattern is consistent with a coverage problem: a fixed number of transitions must estimate a larger set of state--action values. It does not show that larger budgets are inherently undesirable, because the dynamic-programming reference is recomputed for each budget. Rather, it shows that the tested tabular learner becomes less competitive as the action space expands.

The FAI learning-rate and exploration results point in the same direction. The smallest tested learning rate, \(\alpha_D=0.05\), gives a lower performance loss than the reference \(0.10\), while losses increase at 0.20 and 0.40. A shorter exploration decay also worsens the 10,000-episode result: reducing the decay duration from 200,000 to 20,000 steps changes the learned return from \(-294.89\) to \(-301.35\). In this setting, retaining exploration for longer appears useful for discovering state--allocation combinations before relying heavily on current estimates. These are empirical trends for the tested configurations, not universal prescriptions. In particular, the 500-episode FAI result should not be read as a matched point on the same learning curve: it uses \(\eta=0.10\), while the 10,000- and 50,000-episode reference runs use \(\eta=0.20\), and its exploration-decay duration is also different.

### 11.2 Joint learning changes the interpretation of training progress

FAI2 changes the learning problem more fundamentally than simply replacing a deterministic attacker with a stochastic one. The attacker is now an adaptive learner that observes the defender's allocation before choosing a target. Its Q-table is indexed by the infection state, the specific defense allocation, and the attacked target. The defender's Q-table remains indexed by state and defense allocation. Consequently, the attacker can learn different responses to different allocations, while the defender must learn allocations that perform well against an opponent whose response is itself changing.

This coupling is visible in the 50,000-episode learning curves. The attacker's moving-average return rises from approximately the low twenties to the low-to-mid forties during the first 10,000 episodes. Over roughly the same interval, the defender's return becomes substantially more negative, moving from around \(-180\) toward approximately \(-280\). Both curves then fluctuate around their later-training levels. This is consistent with the attacker learning more effective responses and increasing pressure on the defender. It is not evidence that the defender is necessarily unlearning: the return being measured is generated by a changing opponent, so a decline can occur even while the defender's own estimates and decisions are adapting.

The frozen-policy evaluations reinforce this interpretation. After 500 episodes, the learned defender obtains a mean return of \(-230.57\), while its paired learned attacker obtains \(33.30\). After 10,000 episodes, these become \(-271.48\) and \(42.03\), respectively. The much stronger attacker return at 10,000 episodes indicates that the 500-episode defender was being evaluated against a less-developed opponent. Thus, the apparently better defender return at 500 episodes is not evidence that shorter training is superior; it is a consequence of evaluating a jointly trained pair at an earlier stage of adaptation. From 10,000 to 50,000 episodes, the attacker return is nearly unchanged (\(42.03\) versus \(41.92\)), while the defender return changes only from \(-271.48\) to \(-273.75\). Together with the substantial across-seed variation in the 50,000-episode defender result, this provides little evidence of a systematic performance gain from extending the reference run beyond 10,000 episodes.

Within each evaluation, however, the learned defender consistently outperforms the fixed highest-value baseline against the same seed's frozen learned attacker. Its mean-return advantage is approximately 30.10, 9.76, and 13.36 at 500, 10,000, and 50,000 training episodes, respectively. The accompanying non-discounted statistics help explain this advantage. At 10,000 episodes, for example, the learned defender has lower cumulative infected-target loss (about 1,421.8 versus 1,435.3) and lower defense cost (about 103.9 versus 150.0) than the highest-value baseline. At 50,000 episodes, it again has both lower cumulative loss (about 1,423.0 versus 1,469.6) and lower defense cost (about 116.9 versus 150.0). The learned policy is therefore not merely spending more defense to suppress infections. It is selecting allocations more selectively.

This behavior is consistent with the state-dependent action architecture. The highest-value baseline always allocates one unit to the two highest-valued targets, regardless of the current infection state. By contrast, the learned defender can choose among all 21 legal allocations for each state and can leave budget unused. Since an allocation reduces the probability of a *new* infection and does not directly prevent an already infected target from remaining infected or recovering, continuing to defend an infected target can waste resources in the current turn. A state-conditioned policy can redirect protection toward healthy targets that remain vulnerable, or reduce expenditure when further defense is not worthwhile. The evaluation results are consistent with the learned defender exploiting this flexibility. They do not, by themselves, identify the precise internal decision rule learned in every state.

### 11.3 The reward and move-order architecture matter

The two agents do not optimize opposite versions of a single reward. The defender is penalized for the weighted value of all targets infected at the beginning of a turn and for the cost of the selected defense. The attacker receives a target's value only when its action creates a new infection, and it pays the attack cost on every attempt. The attacker is therefore rewarded for successful new infections, while the defender continues to incur loss from infected targets over subsequent turns until recovery. These different reward timings and cost terms make FAI2 a general-sum game. The observed rise in attacker return alongside a decline in defender return is an empirical pattern in the reference run, not a mathematical requirement that the two returns be negatives of each other.

The sequential move order is also reflected in the table representations. The attacker observes \((x_t,d_t)\) before choosing \(a_t\), so \(Q_A(x,d,a)\) can represent the value of attacking each target under the allocation actually selected. The defender does not observe the attacker's current action when choosing its allocation; its \(Q_D(x,d)\) instead learns the consequences of choosing \(d\) under the attacker's evolving response. In the attacker update, the expected continuation value averages over the defender's next epsilon-greedy allocation and then maximizes over the next attack target. This is consistent with the order in which the agents act. Nevertheless, it remains an independent-learning update: the defender's policy used in this expectation is changing during training, and the two value tables are not jointly solved as a game-theoretic fixed point.

A second consequence is that the FAI and FAI2 attackers should not be treated as interchangeable. The FAI attacker is a myopic best response to the current allocation, maximizing immediate expected utility. The FAI2 attacker uses a learned action-value function to maximize its own discounted return. Its policy can therefore reflect expected future rewards, not only the immediate infection probability and value. The FAI dynamic-programming solution is optimal for the fixed greedy-attacker model; it is not an optimality certificate for FAI2, where no equilibrium or best-response solution is reported in the saved experiments.

### 11.4 Hyperparameter sensitivity and opponent transfer

The FAI2 sensitivity runs show that the choice of learning rates matters for both agents. Reducing the defender learning rate from 0.10 to 0.05 improves the mean defender return in the 10,000- and 50,000-episode sensitivity runs, whereas increasing it to 0.20 or 0.40 gives worse returns. This is consistent with more conservative updates being useful when the target values are changing as the opponent adapts, although the experiments do not isolate that mechanism. The attacker learning-rate and exploration-decay results are not monotonic across all training lengths. In a two-learner system, changing one agent's update or exploration schedule changes the data distribution experienced by the other agent as well; the effect cannot be interpreted as a purely local change to one learner. The one-factor sweeps are therefore useful sensitivity checks, but they do not identify a universally best pair of learning rates or decay schedules.

The cross-play results provide further evidence that a defender's performance depends on the opponent used at evaluation. At 10,000 training episodes, the FAI2-trained defender obtains \(-271.48\) against its paired frozen learned attacker but \(-290.12\) against the deterministic greedy attacker. The FAI-trained defender evaluated against a frozen FAI2 attacker obtains \(-283.73\). These values should not be used to rank the two training architectures directly: the opponent pairings differ, and the auxiliary cross-play files do not record their own evaluation configuration. Their more limited implication is that policies trained against one response mechanism need not retain the same performance when the opponent is replaced. This is especially relevant for FAI2, because a defender trained jointly with a particular learning attacker may adapt to that attacker's behavior rather than learn a policy robust to all possible attackers.

### 11.5 Limitations and implications

Several limitations bound the conclusions. First, all principal experiments use four training seeds. The reported standard deviations are variation between seed-level evaluation means, not uncertainty estimates from independent training runs at a large sample size. This matters particularly for FAI2, where the 50,000-episode defender return has substantial across-seed variation. Second, the experiments use five targets and start every episode from the all-healthy state. The state space is therefore small and the results do not establish how either tabular architecture scales to larger systems or to different initial infection patterns. The growth in the number of states and legal allocations makes this an important restriction: the defender table has size \(2^K\binom{K+B}{B}\), and the attacker table has size \(K2^K\binom{K+B}{B}\).

Third, the theoretical objectives are infinite-horizon discounted returns, whereas policy evaluation uses 100-step rollouts. The reported comparisons consequently describe finite-horizon performance under the specified reset and evaluation protocol. Fourth, both implementations use constant learning rates, and FAI2 additionally has a non-stationary opponent during joint training. The experiments do not satisfy the conditions needed to claim classical Q-learning convergence for these runs. The observed flattening of a moving-average learning curve should not be interpreted as proof of convergence. Fifth, FAI2 does not include a dynamic-programming best-response benchmark in the saved baseline configurations, and neither training procedure computes a Nash or Stackelberg equilibrium. Finally, the highest-value and uniform baselines produce the same allocation vectors in the tested configurations, so they do not constitute two independent heuristic comparisons.

The results suggest several concrete extensions. A broader evaluation should increase the number of training seeds, vary the initial infection state, and test larger values of \(K\) and \(B\). For FAI2, evaluating each frozen defender against a common suite of attackers would separate opponent-specific adaptation from more general defensive capability. Enabling the available best-response dynamic-programming evaluation against a frozen attacker would also provide a stronger reference than the fixed heuristic. Alternating or temporarily freezing one learner while training the other could help distinguish genuine adaptation from instability caused by simultaneous policy changes. For larger state and action spaces, a function-approximation or structured-action approach would be more appropriate than directly expanding the tabular Q-tables.

Overall, FAI demonstrates that tabular Q-learning can improve on a simple fixed allocation in a stationary, model-defined environment, while exact dynamic programming remains the stronger benchmark. FAI2 shows that independent learning can produce a defender that outperforms the tested static heuristic against its paired learned attacker, but it also exposes the central difficulty of co-adaptation: the meaning of a training return changes as the opponent learns, performance depends on the opponent pairing, and additional training does not automatically produce a better or more stable policy. The evidence supports the usefulness of the two-agent extension as an empirical model of adaptive attacker--defender interaction, but not a claim of optimality, convergence, or equilibrium attainment.

## 12. Contributions and project-completion checklist

The project archive contains implementation and experiment artefacts for both architectures, but it does not include a group-member roster or the original task-allocation sheet. It is therefore possible to verify that the project-level work packages are represented in the archive, but not to assign those outputs to individual students or certify each student's assigned task. The member-wise table below is intentionally left as a fill-in record rather than inventing names or ownership.

### 12.1 Project-level deliverables

| Work package | Evidence in the submitted project archive/report | Project-level status |
|---|---|---|
| Mathematical model and transition dynamics | State/action definitions, transition kernel, rewards, and objectives in Sections 1–3 | Completed in this report |
| FAI single-agent architecture | `FAI/game.py`, `FAI/algorithms.py`, `FAI/main.py`; deterministic greedy attacker, value iteration, and defender Q-learning | Implementation artefacts present |
| FAI2 two-agent architecture | `FAI2/game.py`, `FAI2/algorithms.py`, `FAI2/main.py`; sequential attacker–defender interaction and two Q-learners | Implementation artefacts present |
| Heuristic and DP comparisons | Highest-value baseline and FAI DP benchmark; seed-level result files | Results archived and analyzed |
| Experimental evaluation | Configurations, per-seed CSVs, learning curves, sensitivity runs, and cross-play data under `expts/` | Results archived and analyzed |
| Methodology and algorithm description | Sections 4–6 and 9 | Included |
| Results, plots, and brief interpretation | Section 10 and the accompanying `report_figures/` directory | Included |
| Discussion and limitations | Section 11 | Included |

### 12.2 Individual contribution record

Complete one row for each group member using the task allocation agreed upon during the project. The evidence column should identify a code module, experiment, analysis, or report section that can be checked.

| Team member | Task assigned during the project | Evidence / deliverable produced | Fulfilled? |
|---|---|---|---|
| [Member name] | [Assigned responsibility] | [File, experiment, or report section] | [Complete / Partially complete / Not complete] |
| [Member name] | [Assigned responsibility] | [File, experiment, or report section] | [Complete / Partially complete / Not complete] |
| [Member name] | [Assigned responsibility] | [File, experiment, or report section] | [Complete / Partially complete / Not complete] |

**Attribution note.** The ZIP establishes that the listed project components and outputs exist; it does not establish who authored them or what was assigned to each member. The individual contribution rows must be populated from the group's original task allocation and confirmed by the members before submission. This distinction avoids claiming individual completion without evidence.

## 13. Conclusion

This project develops two tabular learning formulations for a repeated attacker–defender security game. FAI isolates defender learning against a fixed deterministic greedy attacker and provides an exact DP benchmark for that induced MDP. FAI2 extends the setting to sequential independent learning by both agents, with the attacker observing the defender's current allocation. The experiments show that FAI Q-learning improves on a fixed allocation but does not match the DP reference under the tested budgets and training lengths. FAI2's learned defender improves on the highest-value baseline against its paired learned attacker, and its state-conditioned allocations reduce both cumulative infection loss and defense expenditure in the longer baseline evaluations. At the same time, attacker adaptation, sensitivity to learning schedules, and cross-play results show that the learned policies are opponent-dependent.

The principal contribution is thus an implemented and experimentally examined progression from a stationary single-agent MDP to a sequential general-sum learning game. The evidence supports the utility of state-dependent tabular defense and demonstrates the complications introduced by mutual adaptation. It does not establish optimality or equilibrium convergence. Stronger claims would require more training seeds, broader initial-state coverage, a wider set of opponents, and a game-theoretic or best-response benchmark for frozen learned opponents.
